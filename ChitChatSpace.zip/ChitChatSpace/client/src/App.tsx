import { Switch, Route } from "wouter";
import { queryClient } from "./lib/queryClient";
import { QueryClientProvider } from "@tanstack/react-query";
import { Toaster } from "@/components/ui/toaster";
import NotFound from "@/pages/not-found";
import Chat from "@/pages/Chat";
import AuthPage from "@/pages/auth-page";
import VerifyEmailPage from "@/pages/verify-email";
import DirectMessages from "@/pages/DirectMessages";
import Profile from "@/pages/Profile";
import { ProtectedRoute } from "./lib/protected-route";
import { ChatProvider } from "@/hooks/useChat";
import { AuthProvider } from "@/hooks/use-auth";
import AppLayout from "@/components/AppLayout";

function Router() {
  return (
    <Switch>
      {/* Authentication routes */}
      <Route path="/auth" component={AuthPage} />
      <Route path="/verify-email" component={VerifyEmailPage} />
      
      {/* Protected routes with navigation */}
      <Route path="/">
        {() => (
          <AppLayout>
            <ProtectedRoute path="/" component={DirectMessages} />
          </AppLayout>
        )}
      </Route>
      
      <Route path="/messages">
        {() => (
          <AppLayout>
            <ProtectedRoute path="/messages" component={DirectMessages} />
          </AppLayout>
        )}
      </Route>
      
      <Route path="/profile/:userId">
        {(params) => (
          <AppLayout>
            <ProtectedRoute path={`/profile/${params.userId}`} component={Profile} />
          </AppLayout>
        )}
      </Route>
      
      {/* Chat route (legacy) */}
      <Route path="/chat">
        {() => (
          <AppLayout showNavigation={false}>
            <ProtectedRoute path="/chat" component={Chat} />
          </AppLayout>
        )}
      </Route>
      
      {/* 404 Not Found */}
      <Route component={NotFound} />
    </Switch>
  );
}

function App() {
  return (
    <QueryClientProvider client={queryClient}>
      <AuthProvider>
        <ChatProvider>
          <Router />
          <Toaster />
        </ChatProvider>
      </AuthProvider>
    </QueryClientProvider>
  );
}

export default App;
