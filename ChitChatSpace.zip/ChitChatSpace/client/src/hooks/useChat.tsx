import { useCallback, useEffect, useState, createContext, useContext, ReactNode } from 'react';
import { useToast } from "@/hooks/use-toast";
import type { ChatMessage } from '@shared/schema';

type ChatContextType = {
  messages: ChatMessage[];
  usersTyping: Map<number, boolean>;
  activeChannel: number;
  sendMessage: (content: string) => void;
  setTyping: (isTyping: boolean) => void;
  connect: (userId: number) => void;
  setActiveChannel: (channelId: number) => void;
  userStatuses: Map<number, string>;
};

const ChatContext = createContext<ChatContextType | undefined>(undefined);

export const ChatProvider = ({ children }: { children: ReactNode }) => {
  const [socket, setSocket] = useState<WebSocket | null>(null);
  const [connected, setConnected] = useState(false);
  const [messages, setMessages] = useState<ChatMessage[]>([]);
  const [usersTyping, setUsersTyping] = useState<Map<number, boolean>>(new Map());
  const [activeChannel, setActiveChannel] = useState<number>(1); // Default to general channel
  const [userStatuses, setUserStatuses] = useState<Map<number, string>>(new Map());
  const [userId, setUserId] = useState<number | null>(null);
  
  const { toast } = useToast();

  // Connect to WebSocket server
  const connect = useCallback((newUserId: number) => {
    const protocol = window.location.protocol === "https:" ? "wss:" : "ws:";
    const wsUrl = `${protocol}//${window.location.host}/ws`;
    
    const ws = new WebSocket(wsUrl);
    
    ws.onopen = () => {
      setConnected(true);
      setSocket(ws);
      setUserId(newUserId);
      
      // Identify the user to the server
      ws.send(
        JSON.stringify({
          type: 'status',
          payload: {
            action: 'identify',
            userId: newUserId
          }
        })
      );
      
      // Load messages for initial channel
      fetchMessages(activeChannel);
    };
    
    ws.onclose = () => {
      setConnected(false);
      setSocket(null);
      
      toast({
        title: "Connection lost",
        description: "Reconnecting...",
        variant: "destructive",
      });
      
      // Attempt to reconnect after a delay
      setTimeout(() => connect(newUserId), 3000);
    };
    
    ws.onerror = (error) => {
      console.error('WebSocket error:', error);
      toast({
        title: "Connection error",
        description: "Failed to connect to chat server",
        variant: "destructive",
      });
    };
    
    ws.onmessage = (event) => {
      const data = JSON.parse(event.data);
      
      switch (data.type) {
        case 'message':
          if (data.payload.channelId === activeChannel) {
            setMessages((prev) => [...prev, data.payload]);
          }
          break;
          
        case 'typing':
          if (data.payload.channelId === activeChannel) {
            setUsersTyping((prev) => {
              const newMap = new Map(prev);
              if (data.payload.isTyping) {
                newMap.set(data.payload.userId, true);
              } else {
                newMap.delete(data.payload.userId);
              }
              return newMap;
            });
          }
          break;
          
        case 'status':
          setUserStatuses((prev) => {
            const newMap = new Map(prev);
            newMap.set(data.payload.userId, data.payload.status);
            return newMap;
          });
          break;
          
        case 'error':
          toast({
            title: "Error",
            description: data.payload.message,
            variant: "destructive",
          });
          break;
      }
    };
    
    return () => {
      if (ws) {
        ws.close();
      }
    };
  }, [activeChannel, toast]);
  
  // Fetch messages for the active channel
  const fetchMessages = useCallback(async (channelId: number) => {
    try {
      const response = await fetch(`/api/channels/${channelId}/messages`);
      if (!response.ok) {
        throw new Error('Failed to fetch messages');
      }
      
      const data = await response.json();
      setMessages(data);
    } catch (error) {
      console.error('Error fetching messages:', error);
      toast({
        title: "Error",
        description: "Failed to fetch messages",
        variant: "destructive",
      });
    }
  }, [toast]);
  
  // Change active channel
  const handleSetActiveChannel = useCallback((channelId: number) => {
    setActiveChannel(channelId);
    setMessages([]);
    setUsersTyping(new Map());
    
    // Fetch messages for the new channel
    fetchMessages(channelId);
  }, [fetchMessages]);
  
  // Send message
  const sendMessage = useCallback((content: string) => {
    if (!socket || !connected || !content.trim()) return;
    
    // Stop typing indicator
    setTyping(false);
    
    socket.send(
      JSON.stringify({
        type: 'message',
        payload: {
          content,
          channelId: activeChannel
        }
      })
    );
  }, [socket, connected, activeChannel]);
  
  // Set typing status
  const setTyping = useCallback((isTyping: boolean) => {
    if (!socket || !connected || !userId) return;
    
    socket.send(
      JSON.stringify({
        type: 'typing',
        payload: {
          isTyping,
          channelId: activeChannel
        }
      })
    );
  }, [socket, connected, activeChannel, userId]);
  
  // Update messages when active channel changes
  useEffect(() => {
    if (connected) {
      fetchMessages(activeChannel);
    }
  }, [activeChannel, connected, fetchMessages]);

  return (
    <ChatContext.Provider
      value={{
        messages,
        usersTyping,
        activeChannel,
        sendMessage,
        setTyping,
        connect,
        setActiveChannel: handleSetActiveChannel,
        userStatuses
      }}
    >
      {children}
    </ChatContext.Provider>
  );
};

export const useChat = () => {
  const context = useContext(ChatContext);
  if (context === undefined) {
    throw new Error('useChat must be used within a ChatProvider');
  }
  return context;
};
