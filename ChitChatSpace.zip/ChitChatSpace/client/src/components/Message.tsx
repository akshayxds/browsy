import { useState } from "react";
import { format } from "date-fns";
import { type ChatMessage } from "@shared/schema";
import { cn } from "@/lib/utils";

interface MessageProps {
  message: ChatMessage;
  isCurrentUser: boolean;
}

function Message({ message, isCurrentUser }: MessageProps) {
  const [showMenu, setShowMenu] = useState(false);
  
  // Format the timestamp
  const formattedTime = (() => {
    try {
      const date = new Date(message.timestamp);
      return format(date, "h:mm a");
    } catch (error) {
      return "Unknown time";
    }
  })();

  return (
    <div 
      className={cn(
        "flex items-start space-x-3 group",
        isCurrentUser && "justify-end"
      )}
      onMouseEnter={() => setShowMenu(true)}
      onMouseLeave={() => setShowMenu(false)}
    >
      {!isCurrentUser && (
        <div
          className="h-8 w-8 rounded-full flex-shrink-0 flex items-center justify-center"
          style={{ backgroundColor: message.user.color }}
        >
          <span className="text-white text-xs font-medium">
            {message.user.initials}
          </span>
        </div>
      )}
      
      {isCurrentUser && (
        <div 
          className={cn(
            "opacity-0 transition-opacity",
            showMenu && "opacity-100"
          )}
        >
          <button className="p-1 rounded-md hover:bg-gray-100 text-gray-500">
            <svg 
              xmlns="http://www.w3.org/2000/svg" 
              width="14" 
              height="14" 
              viewBox="0 0 24 24" 
              fill="none" 
              stroke="currentColor" 
              strokeWidth="2" 
              strokeLinecap="round" 
              strokeLinejoin="round"
            >
              <circle cx="12" cy="12" r="1" />
              <circle cx="19" cy="12" r="1" />
              <circle cx="5" cy="12" r="1" />
            </svg>
          </button>
        </div>
      )}
      
      <div className={cn("flex-1", isCurrentUser && "flex flex-col items-end")}>
        <div className="flex items-center space-x-2">
          {!isCurrentUser && (
            <span className="font-medium text-sm">{message.user.displayName}</span>
          )}
          <span className="text-xs text-gray-500">{formattedTime}</span>
          {isCurrentUser && (
            <span className="font-medium text-sm">{message.user.displayName}</span>
          )}
        </div>
        
        <div 
          className={cn(
            "message-bubble",
            isCurrentUser 
              ? "message-sent bg-primary text-white rounded-b-sm rounded-tl-xl rounded-tr-xl" 
              : "message-received bg-gray-100 text-gray-900 rounded-b-sm rounded-tl-xl rounded-tr-xl"
          )}
        >
          <p>{message.content}</p>
        </div>
      </div>
      
      {isCurrentUser && (
        <div
          className="h-8 w-8 rounded-full flex-shrink-0 flex items-center justify-center"
          style={{ backgroundColor: message.user.color }}
        >
          <span className="text-white text-xs font-medium">
            {message.user.initials}
          </span>
        </div>
      )}
      
      {!isCurrentUser && (
        <div 
          className={cn(
            "opacity-0 transition-opacity",
            showMenu && "opacity-100"
          )}
        >
          <button className="p-1 rounded-md hover:bg-gray-100 text-gray-500">
            <svg 
              xmlns="http://www.w3.org/2000/svg" 
              width="14" 
              height="14" 
              viewBox="0 0 24 24" 
              fill="none" 
              stroke="currentColor" 
              strokeWidth="2" 
              strokeLinecap="round" 
              strokeLinejoin="round"
            >
              <circle cx="12" cy="12" r="1" />
              <circle cx="19" cy="12" r="1" />
              <circle cx="5" cy="12" r="1" />
            </svg>
          </button>
        </div>
      )}
    </div>
  );
}

export default Message;
