import { useState } from "react";
import { useChat } from "@/hooks/useChat";
import { useAuth } from "@/hooks/use-auth";
import { type User, type Channel } from "@shared/schema";
import { cn } from "@/lib/utils";
import { useLocation } from "wouter";
import { SettingsModal } from "@/components/SettingsModal";

// Exclude password from User type for client-side
type SafeUser = Omit<User, "password">;

interface SidebarProps {
  currentUser: SafeUser;
  users: SafeUser[];
  channels: Channel[];
  isOpen: boolean;
  onClose: () => void;
}

function Sidebar({ currentUser, users, channels, isOpen, onClose }: SidebarProps) {
  const { activeChannel, setActiveChannel, userStatuses } = useChat();
  const { logoutMutation } = useAuth();
  const [, setLocation] = useLocation();
  const [isSettingsOpen, setIsSettingsOpen] = useState(false);

  return (
    <>
      <div
        id="sidebar"
        className={cn(
          "hidden md:flex md:w-72 lg:w-80 flex-col border-r border-gray-200 bg-white",
          // Mobile sidebar
          isOpen ? "fixed inset-0 z-50 block w-3/4" : "hidden"
        )}
      >
        {/* App Logo & Title */}
        <div className="flex items-center justify-between border-b border-gray-200 p-4">
          <div className="flex items-center space-x-2">
            <div className="flex h-10 w-10 items-center justify-center rounded-full bg-primary">
              <span className="font-medium text-white">BR</span>
            </div>
            <h1 className="text-xl font-semibold">Browsy</h1>
          </div>
          <button 
            className="p-2 rounded-full hover:bg-gray-100"
            onClick={onClose}
          >
            <svg 
              xmlns="http://www.w3.org/2000/svg" 
              width="18" 
              height="18" 
              viewBox="0 0 24 24" 
              fill="none" 
              stroke="currentColor" 
              strokeWidth="2" 
              strokeLinecap="round" 
              strokeLinejoin="round" 
              className="text-gray-500"
            >
              <circle cx="12" cy="12" r="1" />
              <circle cx="19" cy="12" r="1" />
              <circle cx="5" cy="12" r="1" />
            </svg>
          </button>
        </div>

        {/* Channels */}
        <div className="border-b border-gray-200 p-4">
          <div className="mb-3 flex items-center justify-between">
            <h2 className="text-sm font-medium text-gray-500">CHANNELS</h2>
            <button className="p-1 rounded-full hover:bg-gray-100 text-gray-500">
              <svg 
                xmlns="http://www.w3.org/2000/svg" 
                width="14" 
                height="14" 
                viewBox="0 0 24 24" 
                fill="none" 
                stroke="currentColor" 
                strokeWidth="2" 
                strokeLinecap="round" 
                strokeLinejoin="round"
              >
                <line x1="12" y1="5" x2="12" y2="19" />
                <line x1="5" y1="12" x2="19" y2="12" />
              </svg>
            </button>
          </div>

          {channels.map((channel) => (
            <button
              key={channel.id}
              className={cn(
                "mb-1 w-full flex items-center justify-between rounded-md p-2 hover:bg-gray-100",
                activeChannel === channel.id && "bg-gray-100"
              )}
              onClick={() => setActiveChannel(channel.id)}
            >
              <div className="flex items-center">
                <span className="text-sm font-medium">
                  # {channel.name}
                </span>
              </div>
              {channel.unreadCount > 0 && (
                <span className="bg-primary text-white text-xs rounded-full px-2 py-1">
                  {channel.unreadCount}
                </span>
              )}
            </button>
          ))}
        </div>

        {/* Direct Messages */}
        <div className="border-b border-gray-200 p-4">
          <div className="mb-3 flex items-center justify-between">
            <h2 className="text-sm font-medium text-gray-500">DIRECT MESSAGES</h2>
            <button className="p-1 rounded-full hover:bg-gray-100 text-gray-500">
              <svg 
                xmlns="http://www.w3.org/2000/svg" 
                width="14" 
                height="14" 
                viewBox="0 0 24 24" 
                fill="none" 
                stroke="currentColor" 
                strokeWidth="2" 
                strokeLinecap="round" 
                strokeLinejoin="round"
              >
                <line x1="12" y1="5" x2="12" y2="19" />
                <line x1="5" y1="12" x2="19" y2="12" />
              </svg>
            </button>
          </div>

          {users.map((user) => (
            <div
              key={user.id}
              className="mb-1 w-full flex items-center p-2 rounded-md hover:bg-gray-100 space-x-3"
            >
              <div className="relative">
                <div
                  className="h-8 w-8 rounded-full flex items-center justify-center"
                  style={{ backgroundColor: user.color }}
                >
                  <span className="text-xs font-medium text-white">
                    {user.initials}
                  </span>
                </div>
                <div
                  className={cn(
                    "absolute -bottom-0.5 -right-0.5 h-3 w-3 rounded-full border-2 border-white",
                    userStatuses.get(user.id) === "online" && "bg-green-500",
                    userStatuses.get(user.id) === "offline" && "bg-gray-400",
                    userStatuses.get(user.id) === "away" && "bg-yellow-500"
                  )}
                ></div>
              </div>
              <div className="flex-grow flex items-center">
                <span className="text-sm font-medium">{user.displayName}</span>
                {user.id === currentUser.id && 
                  <span className="ml-2 text-xs bg-gray-200 text-gray-700 px-1.5 py-0.5 rounded-full">You</span>
                }
              </div>
              <div className="flex space-x-1">
                <button 
                  className="p-1.5 rounded-md hover:bg-gray-200 text-gray-700"
                  title="Chat with user"
                >
                  <svg 
                    xmlns="http://www.w3.org/2000/svg" 
                    width="14" 
                    height="14" 
                    viewBox="0 0 24 24" 
                    fill="none" 
                    stroke="currentColor" 
                    strokeWidth="2" 
                    strokeLinecap="round" 
                    strokeLinejoin="round"
                  >
                    <path d="M21 15a2 2 0 0 1-2 2H7l-4 4V5a2 2 0 0 1 2-2h14a2 2 0 0 1 2 2z" />
                  </svg>
                </button>
                <button 
                  className="p-1.5 rounded-md hover:bg-gray-200 text-gray-700"
                  title="Add to favorites"
                >
                  <svg 
                    xmlns="http://www.w3.org/2000/svg" 
                    width="14" 
                    height="14" 
                    viewBox="0 0 24 24" 
                    fill="none" 
                    stroke="currentColor" 
                    strokeWidth="2" 
                    strokeLinecap="round" 
                    strokeLinejoin="round"
                  >
                    <path d="M19 21l-7-5-7 5V5a2 2 0 0 1 2-2h10a2 2 0 0 1 2 2z"></path>
                  </svg>
                </button>
              </div>
            </div>
          ))}
        </div>

        {/* User Profile */}
        <div className="mt-auto border-t border-gray-200 p-4">
          <div className="flex items-center space-x-3">
            <div className="relative">
              <div
                className="h-10 w-10 rounded-full flex items-center justify-center"
                style={{ backgroundColor: currentUser.color }}
              >
                <span className="font-medium text-white">
                  {currentUser.initials}
                </span>
              </div>
              <div className="absolute -bottom-0.5 -right-0.5 h-3 w-3 rounded-full bg-green-500 border-2 border-white"></div>
            </div>
            <div>
              <div className="text-sm font-medium">{currentUser.displayName}</div>
              <div className="text-xs text-gray-500">Online</div>
            </div>
            <div className="ml-auto flex space-x-1">
              <button 
                className="p-2 rounded-full hover:bg-gray-100 text-gray-500"
                title="Settings"
                onClick={() => setIsSettingsOpen(true)}
              >
                <svg 
                  xmlns="http://www.w3.org/2000/svg" 
                  width="16" 
                  height="16" 
                  viewBox="0 0 24 24" 
                  fill="none" 
                  stroke="currentColor" 
                  strokeWidth="2" 
                  strokeLinecap="round" 
                  strokeLinejoin="round"
                >
                  <path d="M12.22 2h-.44a2 2 0 0 0-2 2v.18a2 2 0 0 1-1 1.73l-.43.25a2 2 0 0 1-2 0l-.15-.08a2 2 0 0 0-2.73.73l-.22.38a2 2 0 0 0 .73 2.73l.15.1a2 2 0 0 1 1 1.72v.51a2 2 0 0 1-1 1.74l-.15.09a2 2 0 0 0-.73 2.73l.22.38a2 2 0 0 0 2.73.73l.15-.08a2 2 0 0 1 2 0l.43.25a2 2 0 0 1 1 1.73V20a2 2 0 0 0 2 2h.44a2 2 0 0 0 2-2v-.18a2 2 0 0 1 1-1.73l.43-.25a2 2 0 0 1 2 0l.15.08a2 2 0 0 0 2.73-.73l.22-.39a2 2 0 0 0-.73-2.73l-.15-.08a2 2 0 0 1-1-1.74v-.5a2 2 0 0 1 1-1.74l.15-.09a2 2 0 0 0 .73-2.73l-.22-.38a2 2 0 0 0-2.73-.73l-.15.08a2 2 0 0 1-2 0l-.43-.25a2 2 0 0 1-1-1.73V4a2 2 0 0 0-2-2z" />
                  <circle cx="12" cy="12" r="3" />
                </svg>
              </button>
              <button 
                className="p-2 rounded-full hover:bg-gray-100 text-gray-500"
                onClick={() => {
                  logoutMutation.mutate(undefined, {
                    onSuccess: () => {
                      setLocation('/auth');
                    }
                  });
                }}
                title="Logout"
              >
                <svg 
                  xmlns="http://www.w3.org/2000/svg" 
                  width="16" 
                  height="16" 
                  viewBox="0 0 24 24" 
                  fill="none" 
                  stroke="currentColor" 
                  strokeWidth="2" 
                  strokeLinecap="round" 
                  strokeLinejoin="round"
                >
                  <path d="M9 21H5a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2h4" />
                  <polyline points="16 17 21 12 16 7" />
                  <line x1="21" y1="12" x2="9" y2="12" />
                </svg>
              </button>
            </div>
          </div>
        </div>
      </div>

      {/* Settings Modal */}
      <SettingsModal 
        isOpen={isSettingsOpen}
        onClose={() => setIsSettingsOpen(false)}
      />
    </>
  );
}

export default Sidebar;
