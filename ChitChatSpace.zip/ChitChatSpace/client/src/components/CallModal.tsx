import { useState, useEffect } from 'react';
import { User } from '@shared/schema';
import { 
  Dialog, 
  DialogContent, 
  DialogHeader,
  DialogTitle,
  DialogDescription,
  DialogFooter
} from '@/components/ui/dialog';
import { Avatar, AvatarFallback, AvatarImage } from '@/components/ui/avatar';
import { Button } from '@/components/ui/button';
import { Mic, MicOff, Video, VideoOff, PhoneOff } from 'lucide-react';
import { socket, isSocketConnected } from '@/lib/socket';

// Omit password from User type
type SafeUser = Omit<User, "password">;

type CallStatus = 'ringing' | 'ongoing' | 'ended';

type CallModalProps = {
  isOpen: boolean;
  currentUser: SafeUser;
  recipient?: SafeUser | null;
  isIncoming: boolean;
  isVideo: boolean;
  onClose: () => void;
};

export default function CallModal({
  isOpen,
  currentUser,
  recipient,
  isIncoming,
  isVideo,
  onClose
}: CallModalProps) {
  const [callStatus, setCallStatus] = useState<CallStatus>('ringing');
  const [isMuted, setIsMuted] = useState(false);
  const [isVideoEnabled, setIsVideoEnabled] = useState(isVideo);
  const [callDuration, setCallDuration] = useState(0);
  
  // For real implementation, we would use WebRTC here
  // This is a simplified version that simulates a call
  
  // Initialize call timer when the call is connected
  useEffect(() => {
    let timer: NodeJS.Timeout;
    
    if (callStatus === 'ongoing') {
      timer = setInterval(() => {
        setCallDuration(prev => prev + 1);
      }, 1000);
    }
    
    return () => {
      if (timer) clearInterval(timer);
    };
  }, [callStatus]);
  
  // Format call duration as MM:SS
  const formatDuration = (seconds: number) => {
    const mins = Math.floor(seconds / 60);
    const secs = seconds % 60;
    return `${mins.toString().padStart(2, '0')}:${secs.toString().padStart(2, '0')}`;
  };
  
  // Handle accepting the call
  const handleAcceptCall = () => {
    if (isSocketConnected()) {
      socket.send(JSON.stringify({
        type: 'call_response',
        payload: {
          recipientId: recipient?.id,
          accepted: true,
          isVideo
        }
      }));
      setCallStatus('ongoing');
    }
  };
  
  // Handle declining/ending the call
  const handleEndCall = () => {
    if (isSocketConnected()) {
      socket.send(JSON.stringify({
        type: 'call_end',
        payload: {
          recipientId: recipient?.id
        }
      }));
    }
    
    setCallStatus('ended');
    setTimeout(onClose, 500); // Give a small delay before closing
  };
  
  // Handle toggling mute
  const handleToggleMute = () => {
    setIsMuted(!isMuted);
  };
  
  // Handle toggling video
  const handleToggleVideo = () => {
    setIsVideoEnabled(!isVideoEnabled);
  };

  // If no recipient, don't show anything
  if (!recipient) return null;
  
  return (
    <Dialog open={isOpen} onOpenChange={(open) => {
      if (!open) handleEndCall();
    }}>
      <DialogContent className="sm:max-w-md">
        <DialogHeader>
          <DialogTitle>
            {isIncoming ? 'Incoming Call' : callStatus === 'ringing' ? 'Calling...' : 'Call Connected'}
          </DialogTitle>
          <DialogDescription>
            {callStatus === 'ongoing' ? `Call duration: ${formatDuration(callDuration)}` : ''}
          </DialogDescription>
        </DialogHeader>
        
        <div className="flex flex-col items-center py-6 space-y-4">
          <Avatar className="h-24 w-24">
            <AvatarImage src={recipient.profilePicture} />
            <AvatarFallback 
              style={{ backgroundColor: recipient.color }}
              className="text-2xl text-white"
            >
              {recipient.initials}
            </AvatarFallback>
          </Avatar>
          
          <div className="text-center">
            <h3 className="text-xl font-semibold">{recipient.displayName || recipient.username}</h3>
            <p className="text-sm text-muted-foreground">
              {callStatus === 'ringing' 
                ? isIncoming ? 'is calling you...' : 'Ringing...'
                : isVideo ? 'Video Call' : 'Voice Call'
              }
            </p>
          </div>
          
          {isVideo && callStatus === 'ongoing' && (
            <div className="w-full aspect-video bg-muted rounded-lg flex items-center justify-center">
              {isVideoEnabled ? (
                <p className="text-muted-foreground">Video stream would appear here</p>
              ) : (
                <VideoOff className="h-12 w-12 text-muted-foreground/50" />
              )}
            </div>
          )}
        </div>
        
        <DialogFooter className="flex flex-row justify-center gap-4 sm:justify-center">
          {callStatus === 'ringing' && isIncoming ? (
            // Incoming call - show accept/decline
            <>
              <Button variant="destructive" size="icon" onClick={handleEndCall}>
                <PhoneOff className="h-6 w-6" />
              </Button>
              <Button variant="default" size="icon" onClick={handleAcceptCall} className="bg-green-600 hover:bg-green-700">
                <span className="h-6 w-6 flex items-center justify-center">
                  {isVideo ? <Video /> : <Mic />}
                </span>
              </Button>
            </>
          ) : callStatus === 'ongoing' ? (
            // Ongoing call - show controls
            <>
              <Button
                variant={isMuted ? "default" : "outline"}
                size="icon"
                onClick={handleToggleMute}
                className={isMuted ? "bg-red-600 hover:bg-red-700" : ""}
              >
                {isMuted ? <MicOff className="h-5 w-5" /> : <Mic className="h-5 w-5" />}
              </Button>
              
              {isVideo && (
                <Button
                  variant={isVideoEnabled ? "outline" : "default"}
                  size="icon"
                  onClick={handleToggleVideo}
                  className={!isVideoEnabled ? "bg-red-600 hover:bg-red-700" : ""}
                >
                  {isVideoEnabled ? <Video className="h-5 w-5" /> : <VideoOff className="h-5 w-5" />}
                </Button>
              )}
              
              <Button variant="destructive" size="icon" onClick={handleEndCall}>
                <PhoneOff className="h-5 w-5" />
              </Button>
            </>
          ) : (
            // Outgoing call that hasn't been answered yet - show end call only
            <Button variant="destructive" size="icon" onClick={handleEndCall}>
              <PhoneOff className="h-6 w-6" />
            </Button>
          )}
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
}