import { useState } from "react";
import { User } from "@shared/schema";
import { useQuery } from "@tanstack/react-query";
import { Loader2, Search, UserPlus, MessageCircle, User as UserIcon } from "lucide-react";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import { 
  Dialog, 
  DialogContent, 
  DialogHeader, 
  DialogTitle, 
  DialogTrigger 
} from "@/components/ui/dialog";
import { ScrollArea } from "@/components/ui/scroll-area";
import { Link } from "wouter";

// Omit password from User type
type SafeUser = Omit<User, "password">;

type DirectMessagesListProps = {
  currentUser: SafeUser;
  onSelectUser: (user: SafeUser) => void;
  selectedUserId?: number;
};

export default function DirectMessagesList({ 
  currentUser, 
  onSelectUser, 
  selectedUserId 
}: DirectMessagesListProps) {
  const [searchQuery, setSearchQuery] = useState("");
  const [isAddContactDialogOpen, setIsAddContactDialogOpen] = useState(false);
  
  // Fetch conversation partners (users the current user has chatted with)
  const { data: conversationPartners = [], isLoading: isLoadingPartners } = useQuery<SafeUser[]>({
    queryKey: ['/api/conversation-partners'],
    queryFn: async () => {
      const response = await fetch('/api/conversation-partners');
      if (!response.ok) {
        throw new Error('Failed to fetch conversation partners');
      }
      return response.json();
    },
  });

  // Fetch all users for the "Add Contact" dialog
  const { data: allUsers = [], isLoading: isLoadingAllUsers } = useQuery<SafeUser[]>({
    queryKey: ['/api/users'],
    queryFn: async () => {
      const response = await fetch('/api/users');
      if (!response.ok) {
        throw new Error('Failed to fetch users');
      }
      return response.json();
    },
    // Only fetch when the add contact dialog is open to save resources
    enabled: isAddContactDialogOpen,
  });

  // Filter conversation partners based on search
  const filteredPartners = conversationPartners.filter(user => 
    user.username.toLowerCase().includes(searchQuery.toLowerCase()) || 
    (user.displayName && user.displayName.toLowerCase().includes(searchQuery.toLowerCase()))
  );

  // Filter all users for the add contact dialog
  const filteredAllUsers = allUsers.filter(user => 
    user.id !== currentUser.id && 
    (user.username.toLowerCase().includes(searchQuery.toLowerCase()) || 
     (user.displayName && user.displayName.toLowerCase().includes(searchQuery.toLowerCase())))
  );

  // Handle search input
  const handleSearchChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    setSearchQuery(e.target.value);
  };

  // Handle user selection
  const handleSelectUser = (user: SafeUser) => {
    onSelectUser(user);
    setIsAddContactDialogOpen(false);
  };

  return (
    <div className="h-full flex flex-col">
      <div className="flex items-center justify-between p-4 border-b">
        <h2 className="font-semibold text-lg">Direct Messages</h2>
        <Dialog open={isAddContactDialogOpen} onOpenChange={setIsAddContactDialogOpen}>
          <DialogTrigger asChild>
            <Button variant="ghost" size="icon">
              <UserPlus className="h-5 w-5" />
            </Button>
          </DialogTrigger>
          <DialogContent>
            <DialogHeader>
              <DialogTitle>Start a conversation</DialogTitle>
            </DialogHeader>
            <div className="mt-4">
              <Input
                placeholder="Search users..."
                value={searchQuery}
                onChange={handleSearchChange}
                className="mb-4"
              />
              
              {isLoadingAllUsers ? (
                <div className="flex justify-center py-4">
                  <Loader2 className="h-6 w-6 animate-spin text-primary" />
                </div>
              ) : filteredAllUsers.length === 0 ? (
                <div className="text-center py-4 text-muted-foreground">
                  No users found
                </div>
              ) : (
                <ScrollArea className="h-[300px]">
                  <div className="space-y-2">
                    {filteredAllUsers.map((user: SafeUser) => (
                      <div key={user.id} className="flex w-full">
                        <Button
                          variant="ghost"
                          className="flex-1 justify-start h-auto py-2"
                          onClick={() => handleSelectUser(user)}
                        >
                          <Avatar className="h-8 w-8 mr-2">
                            <AvatarImage src={user.profilePicture} />
                            <AvatarFallback 
                              style={{ backgroundColor: user.color }}
                              className="text-white text-xs"
                            >
                              {user.initials}
                            </AvatarFallback>
                          </Avatar>
                          <div className="text-left">
                            <div className="font-medium">{user.displayName || user.username}</div>
                            <div className="text-xs text-muted-foreground">@{user.username}</div>
                          </div>
                        </Button>
                        <Link href={`/profile/${user.id}`}>
                          <Button variant="ghost" size="icon" className="h-auto py-2">
                            <UserIcon className="h-4 w-4" />
                          </Button>
                        </Link>
                      </div>
                    ))}
                  </div>
                </ScrollArea>
              )}
            </div>
          </DialogContent>
        </Dialog>
      </div>
      
      <div className="p-3">
        <div className="relative">
          <Search className="h-4 w-4 absolute left-3 top-3 text-muted-foreground" />
          <Input
            placeholder="Search conversations..."
            value={searchQuery}
            onChange={handleSearchChange}
            className="pl-9"
          />
        </div>
      </div>
      
      <ScrollArea className="flex-1">
        <div className="space-y-1 p-2">
          {isLoadingPartners ? (
            <div className="flex justify-center py-4">
              <Loader2 className="h-6 w-6 animate-spin text-primary" />
            </div>
          ) : filteredPartners.length === 0 ? (
            <div className="text-center py-10 text-muted-foreground flex flex-col items-center">
              <MessageCircle className="h-10 w-10 mb-2 text-muted-foreground/50" />
              <p>No conversations found</p>
              <p className="text-sm">Start a new conversation using the + button</p>
            </div>
          ) : (
            filteredPartners.map((user: SafeUser) => (
              <div key={user.id} className="flex w-full">
                <Button
                  variant={selectedUserId === user.id ? "secondary" : "ghost"}
                  className="flex-1 justify-start h-auto py-3"
                  onClick={() => onSelectUser(user)}
                >
                  <div className="relative">
                    <Avatar className="h-9 w-9 mr-3">
                      <AvatarImage src={user.profilePicture} />
                      <AvatarFallback 
                        style={{ backgroundColor: user.color }}
                        className="text-white text-xs"
                      >
                        {user.initials}
                      </AvatarFallback>
                    </Avatar>
                    {user.status === 'online' && (
                      <span className="absolute bottom-0 right-3 h-2.5 w-2.5 rounded-full bg-green-500 ring-1 ring-background" />
                    )}
                  </div>
                  <div className="text-left overflow-hidden">
                    <div className="font-medium truncate">{user.displayName || user.username}</div>
                    <div className="text-xs text-muted-foreground truncate">
                      {user.status === 'online' ? 'Online' : 'Offline'}
                    </div>
                  </div>
                </Button>
                <Link href={`/profile/${user.id}`}>
                  <Button variant="ghost" size="icon" className="h-auto py-2">
                    <UserIcon className="h-4 w-4" />
                  </Button>
                </Link>
              </div>
            ))
          )}
        </div>
      </ScrollArea>
    </div>
  );
}