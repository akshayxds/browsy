import { Link, useLocation } from "wouter";
import { User } from "@shared/schema";
import { useAuth } from "@/hooks/use-auth";
import {
  MessageSquare,
  User as UserIcon,
  LogOut,
  Settings,
  ChevronDown,
} from "lucide-react";
import { cn } from "@/lib/utils";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuSeparator,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu";
import { Button } from "@/components/ui/button";

// Omit password from User type
type SafeUser = Omit<User, "password">;

export default function Navigation({ className }: { className?: string }) {
  const [location] = useLocation();
  const { user, logoutMutation } = useAuth();
  const [_, setLocation] = useLocation();

  if (!user) return null;

  const handleLogout = () => {
    logoutMutation.mutate();
    // Redirect to auth page after logout
    setLocation("/auth");
  };

  const navItems = [
    {
      name: "Messages",
      path: "/",
      icon: MessageSquare,
      active: location === "/" || location === "/messages"
    }
  ];

  return (
    <div className={cn("fixed bottom-0 left-0 right-0 bg-background border-t z-50 md:relative md:border-t-0 md:border-r", className)}>
      <div className="p-2">
        <div className="flex md:flex-col items-center justify-around">
          {navItems.map((item) => (
            <Link 
              key={item.path} 
              href={item.path}
              className={cn(
                "flex flex-col items-center justify-center p-2 rounded-lg transition-colors",
                "hover:bg-accent hover:text-accent-foreground",
                item.active ? "text-primary font-medium" : "text-muted-foreground"
              )}
            >
              <item.icon className="h-6 w-6 md:h-7 md:w-7" />
              <span className="text-xs mt-1">{item.name}</span>
            </Link>
          ))}
          
          {/* Profile Menu Dropdown */}
          <DropdownMenu>
            <DropdownMenuTrigger asChild>
              <Button 
                variant="ghost" 
                className={cn(
                  "flex flex-col items-center justify-center p-2 rounded-lg transition-colors w-full",
                  "hover:bg-accent hover:text-accent-foreground",
                  location.startsWith("/profile") ? "text-primary font-medium" : "text-muted-foreground"
                )}
              >
                <Avatar className="h-6 w-6 md:h-7 md:w-7">
                  <AvatarImage src={user.profilePicture} alt={user.displayName} />
                  <AvatarFallback>{user.initials}</AvatarFallback>
                </Avatar>
                <span className="text-xs mt-1 flex items-center">
                  Profile
                  <ChevronDown className="ml-1 h-3 w-3" />
                </span>
              </Button>
            </DropdownMenuTrigger>
            <DropdownMenuContent align="end" className="w-56">
              <Link href={`/profile/${user.id}`}>
                <DropdownMenuItem>
                  <UserIcon className="mr-2 h-4 w-4" />
                  <span>My Profile</span>
                </DropdownMenuItem>
              </Link>
              <DropdownMenuItem>
                <Settings className="mr-2 h-4 w-4" />
                <span>Settings</span>
              </DropdownMenuItem>
              <DropdownMenuSeparator />
              <DropdownMenuItem onClick={handleLogout} className="text-red-500 focus:text-red-500">
                <LogOut className="mr-2 h-4 w-4" />
                <span>Logout</span>
              </DropdownMenuItem>
            </DropdownMenuContent>
          </DropdownMenu>
        </div>
      </div>
    </div>
  );
}