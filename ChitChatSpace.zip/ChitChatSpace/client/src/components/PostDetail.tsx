import { useState } from "react";
import { useQuery, useMutation } from "@tanstack/react-query";
import { useAuth } from "@/hooks/use-auth";
import { queryClient } from "@/lib/queryClient";
import { PostData, CommentData } from "@shared/schema";
import { useToast } from "@/hooks/use-toast";
import { Loader2, ThumbsUp, MessageSquare, Heart, Send } from "lucide-react";
import { Button } from "@/components/ui/button";
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";
import { Input } from "@/components/ui/input";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import { Separator } from "@/components/ui/separator";
import { format } from "date-fns";

interface PostDetailProps {
  postId: number;
  isOpen: boolean;
  onClose: () => void;
}

export default function PostDetail({ postId, isOpen, onClose }: PostDetailProps) {
  const { user } = useAuth();
  const { toast } = useToast();
  const [newComment, setNewComment] = useState("");

  // Fetch post details
  const { data: post, isLoading: isLoadingPost } = useQuery<PostData>({
    queryKey: [`/api/posts/${postId}`],
    queryFn: async () => {
      const response = await fetch(`/api/posts/${postId}`);
      if (!response.ok) {
        throw new Error('Failed to fetch post details');
      }
      return response.json();
    },
    enabled: isOpen && !!postId,
  });

  // Fetch post comments
  const { data: comments = [], isLoading: isLoadingComments } = useQuery<CommentData[]>({
    queryKey: [`/api/posts/${postId}/comments`],
    queryFn: async () => {
      const response = await fetch(`/api/posts/${postId}/comments`);
      if (!response.ok) {
        throw new Error('Failed to fetch comments');
      }
      return response.json();
    },
    enabled: isOpen && !!postId,
  });

  // Add a comment
  const createCommentMutation = useMutation({
    mutationFn: async (content: string) => {
      const response = await fetch(`/api/posts/${postId}/comments`, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({ content }),
      });
      
      if (!response.ok) {
        const errorData = await response.json();
        throw new Error(errorData.error || 'Failed to add comment');
      }
      
      return response.json();
    },
    onSuccess: () => {
      // Invalidate and refetch comments
      queryClient.invalidateQueries({ queryKey: [`/api/posts/${postId}/comments`] });
      
      // Reset comment input
      setNewComment("");
      
      toast({
        title: "Comment Added",
        description: "Your comment has been added successfully!",
      });
    },
    onError: (error: Error) => {
      toast({
        title: "Error",
        description: error.message,
        variant: "destructive",
      });
    },
  });

  // Handle form submission
  const handleAddComment = (e: React.FormEvent) => {
    e.preventDefault();
    
    if (!newComment.trim()) {
      toast({
        title: "Error",
        description: "Please enter a comment",
        variant: "destructive",
      });
      return;
    }
    
    createCommentMutation.mutate(newComment.trim());
  };

  const isLoading = isLoadingPost || isLoadingComments;

  return (
    <Dialog open={isOpen} onOpenChange={onClose}>
      <DialogContent className="sm:max-w-[900px] max-h-[90vh] overflow-hidden p-0 gap-0">
        {isLoading ? (
          <div className="flex justify-center items-center h-[500px]">
            <Loader2 className="h-8 w-8 animate-spin text-primary" />
          </div>
        ) : post ? (
          <div className="grid grid-cols-1 md:grid-cols-2 h-full">
            {/* Media section */}
            <div className="bg-black flex items-center justify-center h-[500px] md:h-auto">
              {post.mediaType === 'image' ? (
                <img
                  src={post.mediaUrl}
                  alt={post.caption || 'Post image'}
                  className="max-w-full max-h-full object-contain"
                />
              ) : (
                <video
                  src={post.mediaUrl}
                  controls
                  className="max-w-full max-h-full"
                />
              )}
            </div>
            
            {/* Comments section */}
            <div className="flex flex-col h-[500px] md:h-auto">
              <DialogHeader className="px-4 py-2 border-b">
                <div className="flex items-center gap-3">
                  <Avatar className="h-8 w-8">
                    <AvatarImage src={post.user.profilePicture} alt={post.user.displayName} />
                    <AvatarFallback>{post.user.displayName.substring(0, 2).toUpperCase()}</AvatarFallback>
                  </Avatar>
                  <DialogTitle className="text-sm font-medium">{post.user.displayName}</DialogTitle>
                </div>
              </DialogHeader>
              
              {/* Post details and comments */}
              <div className="flex-1 overflow-y-auto px-4 py-2">
                {/* Original post and caption */}
                <div className="flex gap-3 mb-4">
                  <Avatar className="h-8 w-8">
                    <AvatarImage src={post.user.profilePicture} alt={post.user.displayName} />
                    <AvatarFallback>{post.user.displayName.substring(0, 2).toUpperCase()}</AvatarFallback>
                  </Avatar>
                  <div>
                    <div className="flex gap-2 items-baseline">
                      <span className="font-semibold">{post.user.displayName}</span>
                      <span className="text-sm text-muted-foreground">@{post.user.username}</span>
                    </div>
                    {post.caption && <p className="mt-1">{post.caption}</p>}
                    <p className="text-xs text-muted-foreground mt-2">
                      {format(new Date(post.timestamp), 'MMM d, yyyy • h:mm a')}
                    </p>
                  </div>
                </div>
                
                <Separator className="my-4" />
                
                {/* Comments list */}
                {comments.length === 0 ? (
                  <div className="text-center py-8 text-muted-foreground">
                    No comments yet. Be the first to add one!
                  </div>
                ) : (
                  <div className="space-y-4">
                    {comments.map((comment) => (
                      <div key={comment.id} className="flex gap-3">
                        <Avatar className="h-8 w-8">
                          <AvatarImage src={comment.user.profilePicture} alt={comment.user.displayName} />
                          <AvatarFallback>{comment.user.displayName.substring(0, 2).toUpperCase()}</AvatarFallback>
                        </Avatar>
                        <div>
                          <div className="flex gap-2 items-baseline">
                            <span className="font-semibold">{comment.user.displayName}</span>
                            <span className="text-xs text-muted-foreground">
                              {format(new Date(comment.timestamp), 'MMM d, yyyy')}
                            </span>
                          </div>
                          <p className="mt-1">{comment.content}</p>
                        </div>
                      </div>
                    ))}
                  </div>
                )}
              </div>
              
              {/* Post actions */}
              <div className="px-4 py-3 border-t">
                <div className="flex gap-4 mb-3">
                  <Button variant="ghost" size="sm" className="flex items-center gap-1.5">
                    <Heart className="h-5 w-5" />
                    <span>{post.likes || 0}</span>
                  </Button>
                  <Button variant="ghost" size="sm" className="flex items-center gap-1.5">
                    <MessageSquare className="h-5 w-5" />
                    <span>{comments.length}</span>
                  </Button>
                </div>
                
                {/* Add comment form */}
                <form onSubmit={handleAddComment} className="flex gap-2">
                  <Input
                    value={newComment}
                    onChange={(e) => setNewComment(e.target.value)}
                    placeholder="Add a comment..."
                    className="flex-1"
                  />
                  <Button 
                    type="submit" 
                    size="sm"
                    disabled={createCommentMutation.isPending}
                  >
                    {createCommentMutation.isPending ? (
                      <Loader2 className="h-4 w-4 animate-spin" />
                    ) : (
                      <Send className="h-4 w-4" />
                    )}
                  </Button>
                </form>
              </div>
            </div>
          </div>
        ) : (
          <div className="flex justify-center items-center h-[500px]">
            <p className="text-muted-foreground">Post not found</p>
          </div>
        )}
      </DialogContent>
    </Dialog>
  );
}