import { useState, useEffect, useRef } from "react";
import { User } from "@shared/schema";
import { useQuery, useMutation } from "@tanstack/react-query";
import { useParams } from "wouter";
import { Loader2, Send, Image, Paperclip, Mic, Phone, Video } from "lucide-react";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { useToast } from "@/hooks/use-toast";
import { queryClient, apiRequest } from "@/lib/queryClient";
import { socket, isSocketConnected } from "@/lib/socket";

// Omit password from User type
type SafeUser = Omit<User, "password">;

// Message type
type Message = {
  id: number;
  content: string;
  userId: number;
  channelId?: number;
  recipientId?: number;
  isDirectMessage: boolean;
  timestamp: string;
  read: boolean;
  user: {
    username: string;
    displayName: string;
    initials: string;
    color: string;
    profilePicture?: string;
  };
};

type DirectMessageViewProps = {
  currentUser: SafeUser;
  recipient: SafeUser;
  onStartCall: (userId: number, isVideo: boolean) => void;
};

export default function DirectMessageView({ 
  currentUser, 
  recipient, 
  onStartCall 
}: DirectMessageViewProps) {
  const [newMessage, setNewMessage] = useState("");
  const [isTyping, setIsTyping] = useState(false);
  const messagesEndRef = useRef<HTMLDivElement>(null);
  const { toast } = useToast();
  
  // Fetch direct messages between the current user and the recipient
  const { data: messages = [], isLoading } = useQuery<Message[]>({
    queryKey: ['/api/messages/direct', currentUser.id, recipient.id],
    queryFn: async () => {
      const response = await fetch(`/api/messages/direct?userId=${currentUser.id}&recipientId=${recipient.id}`);
      if (!response.ok) {
        throw new Error('Failed to fetch messages');
      }
      return response.json();
    },
    refetchInterval: 3000, // Refetch every 3 seconds as a fallback if WebSocket fails
  });

  // Create message mutation
  const createMessageMutation = useMutation({
    mutationFn: async (content: string) => {
      const response = await apiRequest('POST', '/api/messages', {
        content,
        recipientId: recipient.id,
        isDirectMessage: true,
      });
      return response.json();
    },
    onSuccess: () => {
      // Invalidate and refetch
      queryClient.invalidateQueries({ queryKey: ['/api/messages/direct', currentUser.id, recipient.id] });
    },
    onError: (error: Error) => {
      toast({
        title: 'Failed to send message',
        description: error.message,
        variant: 'destructive',
      });
    },
  });

  // Handle sending a new message
  const handleSendMessage = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!newMessage.trim()) return;
    
    try {
      await createMessageMutation.mutateAsync(newMessage);
      setNewMessage("");
    } catch (error) {
      console.error("Error sending message:", error);
    }
  };

  // Handle typing notifications
  const handleTyping = () => {
    if (isSocketConnected()) {
      socket.send(JSON.stringify({
        type: 'typing',
        payload: {
          userId: currentUser.id,
          recipientId: recipient.id,
          isDirectMessage: true,
          timestamp: Date.now(),
        }
      }));
    }
  };

  // Scroll to bottom when messages change
  useEffect(() => {
    messagesEndRef.current?.scrollIntoView({ behavior: "smooth" });
  }, [messages]);

  // Format timestamp
  const formatTimestamp = (timestamp: string) => {
    const date = new Date(timestamp);
    return date.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' });
  };

  return (
    <div className="flex flex-col h-full">
      {/* Header */}
      <div className="flex items-center justify-between p-4 border-b">
        <div className="flex items-center">
          <Avatar className="h-10 w-10 mr-3">
            <AvatarImage src={recipient.profilePicture} />
            <AvatarFallback 
              style={{ backgroundColor: recipient.color }}
              className="text-white"
            >
              {recipient.initials}
            </AvatarFallback>
          </Avatar>
          <div>
            <h2 className="font-semibold">{recipient.displayName || recipient.username}</h2>
            <p className="text-xs text-muted-foreground">
              {recipient.status === 'online' ? 'Online' : 'Offline'}
            </p>
          </div>
        </div>
        <div className="flex gap-2">
          <Button 
            variant="ghost" 
            size="icon"
            onClick={() => onStartCall(recipient.id, false)}
          >
            <Phone className="h-5 w-5" />
          </Button>
          <Button 
            variant="ghost" 
            size="icon"
            onClick={() => onStartCall(recipient.id, true)}
          >
            <Video className="h-5 w-5" />
          </Button>
        </div>
      </div>

      {/* Messages */}
      <div className="flex-1 overflow-y-auto p-4 space-y-4">
        {isLoading ? (
          <div className="flex justify-center p-4">
            <Loader2 className="h-6 w-6 animate-spin text-primary" />
          </div>
        ) : messages.length === 0 ? (
          <div className="flex flex-col items-center justify-center h-full text-center p-4">
            <div className="bg-primary/10 rounded-full p-4 mb-4">
              <Send className="h-8 w-8 text-primary" />
            </div>
            <h3 className="text-lg font-medium">No messages yet</h3>
            <p className="text-muted-foreground">
              Send your first message to {recipient.displayName || recipient.username}
            </p>
          </div>
        ) : (
          messages.map((message) => {
            const isCurrentUser = message.userId === currentUser.id;
            
            return (
              <div 
                key={message.id} 
                className={`flex ${isCurrentUser ? 'justify-end' : 'justify-start'}`}
              >
                <div className="flex items-end gap-2 max-w-[80%]">
                  {!isCurrentUser && (
                    <Avatar className="h-8 w-8">
                      <AvatarImage src={message.user.profilePicture} />
                      <AvatarFallback 
                        style={{ backgroundColor: message.user.color }}
                        className="text-white text-xs"
                      >
                        {message.user.initials}
                      </AvatarFallback>
                    </Avatar>
                  )}
                  
                  <div 
                    className={`rounded-lg p-3 ${
                      isCurrentUser 
                        ? 'bg-primary text-primary-foreground' 
                        : 'bg-muted'
                    }`}
                  >
                    <p>{message.content}</p>
                    <span className="text-xs opacity-70 block text-right mt-1">
                      {formatTimestamp(message.timestamp)}
                    </span>
                  </div>
                </div>
              </div>
            );
          })
        )}
        <div ref={messagesEndRef} />
      </div>

      {/* Message Input */}
      <form 
        onSubmit={handleSendMessage} 
        className="p-4 border-t flex items-center gap-2"
      >
        <Button 
          type="button" 
          variant="ghost" 
          size="icon"
          className="flex-shrink-0"
        >
          <Paperclip className="h-5 w-5" />
        </Button>
        
        <Input
          value={newMessage}
          onChange={(e) => setNewMessage(e.target.value)}
          onKeyDown={handleTyping}
          placeholder="Type a message..."
          className="flex-1"
          disabled={createMessageMutation.isPending}
        />
        
        <Button 
          type="submit" 
          size="icon" 
          className="flex-shrink-0"
          disabled={!newMessage.trim() || createMessageMutation.isPending}
        >
          {createMessageMutation.isPending ? (
            <Loader2 className="h-5 w-5 animate-spin" />
          ) : (
            <Send className="h-5 w-5" />
          )}
        </Button>
      </form>
    </div>
  );
}