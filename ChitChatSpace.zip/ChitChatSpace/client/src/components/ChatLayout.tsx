import { useState, useEffect } from "react";
import Sidebar from "@/components/Sidebar";
import ChatMain from "@/components/ChatMain";
import { useQuery } from "@tanstack/react-query";
import { type User, type Channel } from "@shared/schema";

// Exclude password from User type for client-side
type SafeUser = Omit<User, "password">;

interface ChatLayoutProps {
  currentUser: SafeUser;
}

function ChatLayout({ currentUser }: ChatLayoutProps) {
  const [mobileSidebarOpen, setMobileSidebarOpen] = useState(false);

  // Fetch channels
  const { data: channels, isLoading: isLoadingChannels } = useQuery<Channel[]>({
    queryKey: ['/api/channels'],
  });

  // Fetch users
  const { data: users, isLoading: isLoadingUsers } = useQuery<SafeUser[]>({
    queryKey: ['/api/users'],
  });

  const toggleMobileSidebar = () => {
    setMobileSidebarOpen(!mobileSidebarOpen);
  };

  // Close sidebar when clicking outside on mobile
  useEffect(() => {
    const handleClickOutside = (event: MouseEvent) => {
      const sidebar = document.querySelector("#sidebar");
      if (mobileSidebarOpen && sidebar && !sidebar.contains(event.target as Node)) {
        setMobileSidebarOpen(false);
      }
    };

    document.addEventListener("mousedown", handleClickOutside);
    return () => {
      document.removeEventListener("mousedown", handleClickOutside);
    };
  }, [mobileSidebarOpen]);

  if (isLoadingChannels || isLoadingUsers) {
    return (
      <div className="flex h-screen items-center justify-center">
        <div className="h-32 w-32 animate-spin rounded-full border-b-2 border-t-2 border-primary"></div>
      </div>
    );
  }

  return (
    <div className="flex h-screen overflow-hidden">
      <Sidebar
        currentUser={currentUser}
        users={users || []}
        channels={channels || []}
        isOpen={mobileSidebarOpen}
        onClose={() => setMobileSidebarOpen(false)}
      />
      <ChatMain
        currentUser={currentUser}
        users={users || []}
        channels={channels || []}
        onToggleSidebar={toggleMobileSidebar}
      />
    </div>
  );
}

export default ChatLayout;
