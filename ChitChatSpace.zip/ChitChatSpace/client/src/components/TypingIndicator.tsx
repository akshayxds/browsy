import { type User } from "@shared/schema";

// Exclude password from User type for client-side
type SafeUser = Omit<User, "password">;

interface TypingIndicatorProps {
  user: SafeUser;
}

function TypingIndicator({ user }: TypingIndicatorProps) {
  return (
    <div className="flex items-start space-x-3">
      <div 
        className="h-8 w-8 rounded-full flex-shrink-0 flex items-center justify-center"
        style={{ backgroundColor: user.color }}
      >
        <span className="text-white text-xs font-medium">{user.initials}</span>
      </div>
      <div className="message-bubble message-received bg-gray-100 py-2 px-4 rounded-b-sm rounded-tl-xl rounded-tr-xl">
        <div className="flex space-x-1">
          <span className="h-2 w-2 bg-primary rounded-full animate-bounce" style={{ animationDelay: "0s" }}></span>
          <span className="h-2 w-2 bg-primary rounded-full animate-bounce" style={{ animationDelay: "0.2s" }}></span>
          <span className="h-2 w-2 bg-primary rounded-full animate-bounce" style={{ animationDelay: "0.4s" }}></span>
        </div>
      </div>
    </div>
  );
}

export default TypingIndicator;
