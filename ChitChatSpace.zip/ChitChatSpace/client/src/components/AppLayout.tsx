import { ReactNode } from "react";
import { useAuth } from "@/hooks/use-auth";
import { Loader2 } from "lucide-react";
import Navigation from "./Navigation";

interface AppLayoutProps {
  children: ReactNode;
  showNavigation?: boolean;
}

export default function AppLayout({ children, showNavigation = true }: AppLayoutProps) {
  const { user, isLoading } = useAuth();

  if (isLoading) {
    return (
      <div className="flex items-center justify-center min-h-screen">
        <Loader2 className="h-8 w-8 animate-spin text-primary" />
      </div>
    );
  }

  if (!user) {
    return <>{children}</>;
  }

  return (
    <div className="flex min-h-screen bg-background">
      {showNavigation && (
        <div className="hidden md:block w-20 border-r">
          <Navigation className="sticky top-0" />
        </div>
      )}
      <main className="flex-1 pb-16 md:pb-0">
        {children}
      </main>
      {showNavigation && (
        <div className="md:hidden">
          <Navigation />
        </div>
      )}
    </div>
  );
}