import { useState, useEffect } from "react";
import { useRoute } from "wouter";
import { useQuery, useMutation } from "@tanstack/react-query";
import { useAuth } from "@/hooks/use-auth";
import { queryClient } from "@/lib/queryClient";
import { User } from "@shared/schema";
import { useToast } from "@/hooks/use-toast";
import { Loader2, Save, Settings, User as UserIcon, Mail, Key, Image, Upload } from "lucide-react";
import { Button } from "@/components/ui/button";
import {
  Card,
  CardContent,
  CardHeader,
} from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Alert, AlertDescription } from "@/components/ui/alert";

// Omit password from User type
type SafeUser = Omit<User, "password">;
type UpdateType = 'username' | 'email' | 'password' | 'photo';

export default function Profile() {
  const { user } = useAuth();
  const { toast } = useToast();
  const [, params] = useRoute<{ userId: string }>("/profile/:userId");
  const userId = params?.userId ? parseInt(params.userId) : user?.id;
  
  const [activeTab, setActiveTab] = useState<UpdateType>('username');
  const [formError, setFormError] = useState('');
  const [profileData, setProfileData] = useState({
    username: "",
    email: "",
    currentPassword: "",
    newPassword: "",
    confirmPassword: "",
    profilePicture: ""
  });

  // Fetch profile data - use current user data if viewing own profile
  const { data: profileUser, isLoading: isLoadingProfile } = useQuery<SafeUser>({
    queryKey: [`/api/users/${userId}`],
    queryFn: async () => {
      // If viewing own profile and user data is available, use it directly
      if (user && userId === user.id) {
        // User is already a SafeUser type in useAuth
        return user;
      }
      
      // Otherwise fetch the profile data
      const response = await fetch(`/api/users/${userId}`);
      if (!response.ok) {
        throw new Error('Failed to fetch user profile');
      }
      return response.json();
    },
    // This prevents unnecessary fetches when user data is already available
    enabled: userId !== undefined,
  });
  
  // Update form data when profile is loaded
  useEffect(() => {
    if (profileUser) {
      setProfileData({
        username: profileUser.username,
        email: profileUser.email,
        currentPassword: "",
        newPassword: "",
        confirmPassword: "",
        profilePicture: profileUser.profilePicture || ""
      });
    }
  }, [profileUser]);

  // Update profile mutation
  const updateProfileMutation = useMutation({
    mutationFn: async (data: typeof profileData) => {
      const response = await fetch(`/api/users/${userId}`, {
        method: 'PUT',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify(data),
        credentials: 'include', // Include cookies for authentication
      });
      
      if (!response.ok) {
        const errorData = await response.json();
        throw new Error(errorData.error || 'Failed to update profile');
      }
      
      return response.json();
    },
    onSuccess: () => {
      // Invalidate and refetch user data
      queryClient.invalidateQueries({ queryKey: [`/api/users/${userId}`] });
      // Also update the current user if this is the user's own profile
      if (user?.id === userId) {
        queryClient.invalidateQueries({ queryKey: ['/api/user'] });
      }
      
      setFormError('');
      // Reset password fields
      setProfileData(prev => ({
        ...prev,
        currentPassword: "",
        newPassword: "",
        confirmPassword: ""
      }));
      
      toast({
        title: "Profile Updated",
        description: "Your profile has been updated successfully!",
      });
    },
    onError: (error: Error) => {
      setFormError(error.message);
      toast({
        title: "Error",
        description: error.message,
        variant: "destructive",
      });
    },
  });

  // Handle form submissions for different sections
  const handleUpdateUsername = (e: React.FormEvent) => {
    e.preventDefault();
    if (!profileData.currentPassword) {
      setFormError('Current password is required');
      return;
    }
    
    updateProfileMutation.mutate({
      ...profileData,
      // Don't update these on username change
      email: profileUser?.email || "",
      newPassword: "",
      confirmPassword: ""
    });
  };

  const handleUpdateEmail = (e: React.FormEvent) => {
    e.preventDefault();
    if (!profileData.currentPassword) {
      setFormError('Current password is required');
      return;
    }
    
    updateProfileMutation.mutate({
      ...profileData,
      // Don't update these on email change
      username: profileUser?.username || "",
      newPassword: "",
      confirmPassword: ""
    });
  };

  const handleUpdatePassword = (e: React.FormEvent) => {
    e.preventDefault();
    if (!profileData.currentPassword) {
      setFormError('Current password is required');
      return;
    }
    
    if (!profileData.newPassword || !profileData.confirmPassword) {
      setFormError('New password and confirmation are required');
      return;
    }
    
    if (profileData.newPassword !== profileData.confirmPassword) {
      setFormError('New passwords do not match');
      return;
    }
    
    updateProfileMutation.mutate({
      ...profileData,
      // Don't update these on password change
      username: profileUser?.username || "",
      email: profileUser?.email || ""
    });
  };

  const handleUpdatePhoto = (e: React.FormEvent) => {
    e.preventDefault();
    updateProfileMutation.mutate({
      ...profileData,
      // Don't update these on photo change
      username: profileUser?.username || "",
      email: profileUser?.email || "",
      currentPassword: "",
      newPassword: "",
      confirmPassword: ""
    });
  };

  const isOwnProfile = user?.id === userId;

  if (isLoadingProfile || !profileUser) {
    return (
      <div className="flex items-center justify-center min-h-screen">
        <Loader2 className="h-8 w-8 animate-spin text-primary" />
      </div>
    );
  }

  return (
    <div className="container mx-auto py-8">
      <Card className="mb-8">
        <CardContent className="pt-6">
          <div className="flex flex-col md:flex-row gap-8 items-center md:items-start">
            <div className="flex-shrink-0">
              <Avatar className="h-32 w-32">
                <AvatarImage src={profileUser.profilePicture || ''} alt={profileUser.displayName} />
                <AvatarFallback 
                  className="text-4xl"
                  style={{ backgroundColor: profileUser.color }}
                >
                  {profileUser.initials}
                </AvatarFallback>
              </Avatar>
            </div>
            <div className="flex-grow text-center md:text-left">
              <div className="flex flex-col md:flex-row gap-4 md:items-center justify-between mb-4">
                <div>
                  <h1 className="text-3xl font-bold">{profileUser.displayName}</h1>
                  <p className="text-muted-foreground">@{profileUser.username}</p>
                </div>
              </div>
              {profileUser.bio && (
                <div className="mb-4">
                  <p>{profileUser.bio}</p>
                </div>
              )}
            </div>
          </div>
        </CardContent>
      </Card>

      {isOwnProfile && (
        <div className="mt-8 grid grid-cols-1 gap-4">
          <Card>
            <CardHeader>
              <h2 className="text-xl font-semibold">Profile Settings</h2>
              <p className="text-sm text-muted-foreground">Update your account settings</p>
            </CardHeader>
            <CardContent>
              {formError && (
                <Alert variant="destructive" className="mb-4">
                  <AlertDescription>{formError}</AlertDescription>
                </Alert>
              )}
              
              <Tabs value={activeTab} onValueChange={(value) => setActiveTab(value as UpdateType)} className="w-full">
                <TabsList className="grid w-full grid-cols-4">
                  <TabsTrigger value="username">
                    <UserIcon className="h-4 w-4 mr-2" />
                    Username
                  </TabsTrigger>
                  <TabsTrigger value="email">
                    <Mail className="h-4 w-4 mr-2" />
                    Email
                  </TabsTrigger>
                  <TabsTrigger value="password">
                    <Key className="h-4 w-4 mr-2" />
                    Password
                  </TabsTrigger>
                  <TabsTrigger value="photo">
                    <Image className="h-4 w-4 mr-2" />
                    Photo
                  </TabsTrigger>
                </TabsList>
                
                <div className="mt-6">
                  <TabsContent value="username">
                    <form onSubmit={handleUpdateUsername}>
                      <div className="space-y-4">
                        <div className="grid w-full gap-1.5">
                          <Label htmlFor="username">Username</Label>
                          <Input 
                            id="username" 
                            value={profileData.username} 
                            onChange={(e) => setProfileData({ ...profileData, username: e.target.value })}
                            placeholder="username"
                            required
                          />
                          <p className="text-sm text-muted-foreground">
                            This is your public username. It will be visible to other users.
                          </p>
                        </div>

                        <div className="grid w-full gap-1.5">
                          <Label htmlFor="currentPassword">Current Password</Label>
                          <Input 
                            id="currentPassword" 
                            type="password"
                            value={profileData.currentPassword} 
                            onChange={(e) => setProfileData({ ...profileData, currentPassword: e.target.value })}
                            placeholder="Enter your current password"
                            required
                          />
                          <p className="text-sm text-muted-foreground">
                            For security, please confirm your current password.
                          </p>
                        </div>

                        <div className="flex justify-end">
                          <Button type="submit" disabled={updateProfileMutation.isPending}>
                            {updateProfileMutation.isPending ? (
                              <>
                                <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                                Saving...
                              </>
                            ) : (
                              <>
                                <Save className="mr-2 h-4 w-4" />
                                Save Username
                              </>
                            )}
                          </Button>
                        </div>
                      </div>
                    </form>
                  </TabsContent>

                  <TabsContent value="email">
                    <form onSubmit={handleUpdateEmail}>
                      <div className="space-y-4">
                        <div className="grid w-full gap-1.5">
                          <Label htmlFor="email">Email</Label>
                          <Input 
                            id="email" 
                            type="email"
                            value={profileData.email} 
                            onChange={(e) => setProfileData({ ...profileData, email: e.target.value })}
                            placeholder="your@email.com"
                            required
                          />
                          <p className="text-sm text-muted-foreground">
                            This email will be used for account recovery and notifications.
                          </p>
                        </div>

                        <div className="grid w-full gap-1.5">
                          <Label htmlFor="currentPasswordEmail">Current Password</Label>
                          <Input 
                            id="currentPasswordEmail" 
                            type="password"
                            value={profileData.currentPassword} 
                            onChange={(e) => setProfileData({ ...profileData, currentPassword: e.target.value })}
                            placeholder="Enter your current password"
                            required
                          />
                          <p className="text-sm text-muted-foreground">
                            For security, please confirm your current password.
                          </p>
                        </div>

                        <div className="flex justify-end">
                          <Button type="submit" disabled={updateProfileMutation.isPending}>
                            {updateProfileMutation.isPending ? (
                              <>
                                <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                                Saving...
                              </>
                            ) : (
                              <>
                                <Save className="mr-2 h-4 w-4" />
                                Save Email
                              </>
                            )}
                          </Button>
                        </div>
                      </div>
                    </form>
                  </TabsContent>

                  <TabsContent value="password">
                    <form onSubmit={handleUpdatePassword}>
                      <div className="space-y-4">
                        <div className="grid w-full gap-1.5">
                          <Label htmlFor="currentPasswordChange">Current Password</Label>
                          <Input 
                            id="currentPasswordChange" 
                            type="password"
                            value={profileData.currentPassword} 
                            onChange={(e) => setProfileData({ ...profileData, currentPassword: e.target.value })}
                            placeholder="Enter your current password"
                            required
                          />
                        </div>

                        <div className="grid w-full gap-1.5">
                          <Label htmlFor="newPassword">New Password</Label>
                          <Input 
                            id="newPassword" 
                            type="password"
                            value={profileData.newPassword} 
                            onChange={(e) => setProfileData({ ...profileData, newPassword: e.target.value })}
                            placeholder="Enter new password"
                            required
                          />
                        </div>

                        <div className="grid w-full gap-1.5">
                          <Label htmlFor="confirmPassword">Confirm New Password</Label>
                          <Input 
                            id="confirmPassword" 
                            type="password"
                            value={profileData.confirmPassword} 
                            onChange={(e) => setProfileData({ ...profileData, confirmPassword: e.target.value })}
                            placeholder="Confirm new password"
                            required
                          />
                          <p className="text-sm text-muted-foreground">
                            Make sure both passwords match.
                          </p>
                        </div>

                        <div className="flex justify-end">
                          <Button type="submit" disabled={updateProfileMutation.isPending}>
                            {updateProfileMutation.isPending ? (
                              <>
                                <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                                Saving...
                              </>
                            ) : (
                              <>
                                <Save className="mr-2 h-4 w-4" />
                                Change Password
                              </>
                            )}
                          </Button>
                        </div>
                      </div>
                    </form>
                  </TabsContent>

                  <TabsContent value="photo">
                    <form onSubmit={handleUpdatePhoto}>
                      <div className="space-y-4">
                        <div className="grid w-full gap-1.5">
                          <Label htmlFor="profilePictureFile">Upload Profile Picture</Label>
                          <div className="flex items-center space-x-2">
                            <Input
                              id="profilePictureFile"
                              type="file"
                              accept="image/*"
                              className="flex-1"
                              onChange={(e) => {
                                const file = e.target.files?.[0];
                                if (file) {
                                  const reader = new FileReader();
                                  reader.onload = (event) => {
                                    if (event.target?.result) {
                                      setProfileData({
                                        ...profileData,
                                        profilePicture: event.target.result as string
                                      });
                                    }
                                  };
                                  reader.readAsDataURL(file);
                                }
                              }}
                            />
                          </div>
                          <p className="text-sm text-muted-foreground">
                            Select an image file to use as your profile picture.
                          </p>
                        </div>

                        <div className="flex items-center justify-center py-4">
                          <Avatar className="h-24 w-24">
                            <AvatarImage src={profileData.profilePicture || ''} alt="Preview" />
                            <AvatarFallback 
                              className="text-2xl"
                              style={{ backgroundColor: profileUser.color }}
                            >
                              {profileUser.initials}
                            </AvatarFallback>
                          </Avatar>
                        </div>
                        
                        <div className="text-center text-sm text-muted-foreground">
                          {profileData.profilePicture && profileData.profilePicture !== profileUser.profilePicture
                            ? "New image selected. Click 'Update Photo' to save."
                            : "No new image selected."}
                        </div>

                        <div className="flex justify-end">
                          <Button type="submit" disabled={updateProfileMutation.isPending || profileData.profilePicture === profileUser.profilePicture}>
                            {updateProfileMutation.isPending ? (
                              <>
                                <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                                Saving...
                              </>
                            ) : (
                              <>
                                <Save className="mr-2 h-4 w-4" />
                                Update Photo
                              </>
                            )}
                          </Button>
                        </div>
                      </div>
                    </form>
                  </TabsContent>
                </div>
              </Tabs>
            </CardContent>
          </Card>
        </div>
      )}
    </div>
  );
}