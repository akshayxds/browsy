import { useEffect } from "react";
import { useChat } from "@/hooks/useChat";
import ChatLayout from "@/components/ChatLayout";
import { useAuth } from "@/hooks/use-auth";
import { Loader2 } from "lucide-react";

function Chat() {
  const { user } = useAuth();
  const { connect } = useChat();

  // Connect to WebSocket when the user is available
  useEffect(() => {
    if (user) {
      connect(user.id);
    }
  }, [user, connect]);

  if (!user) {
    return (
      <div className="flex items-center justify-center min-h-screen">
        <Loader2 className="h-8 w-8 animate-spin text-primary" />
      </div>
    );
  }

  return <ChatLayout currentUser={user} />;
}

export default Chat;
