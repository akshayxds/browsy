import { useState, useEffect } from "react";
import { User } from "@shared/schema";
import { useAuth } from "@/hooks/use-auth";
import { useToast } from "@/hooks/use-toast";
import { useQuery } from "@tanstack/react-query";
import { Loader2, MessageSquare } from "lucide-react";
import DirectMessagesList from "@/components/DirectMessagesList";
import DirectMessageView from "@/components/DirectMessageView";
import CallModal from "@/components/CallModal";
import { socket, isSocketConnected } from "@/lib/socket";
import { playMessageSound, initAudio } from "@/lib/audio";

// Omit password from User type
type SafeUser = Omit<User, "password">;

type CallState = {
  isActive: boolean;
  isIncoming: boolean;
  isVideo: boolean;
  recipientId?: number;
};

export default function DirectMessages() {
  const { user } = useAuth();
  const { toast } = useToast();
  const [selectedUser, setSelectedUser] = useState<SafeUser | null>(null);
  const [callState, setCallState] = useState<CallState>({
    isActive: false,
    isIncoming: false,
    isVideo: false
  });
  
  // Fetch all users
  const { data: users = [], isLoading } = useQuery<SafeUser[]>({
    queryKey: ['/api/users'],
    queryFn: async () => {
      const response = await fetch('/api/users');
      if (!response.ok) {
        throw new Error('Failed to fetch users');
      }
      return response.json();
    },
  });

  // Handle selecting a user for DM
  const handleSelectUser = (selectedUser: SafeUser) => {
    setSelectedUser(selectedUser);
  };
  
  // Handle starting a call
  const handleStartCall = (userId: number, isVideo: boolean) => {
    if (!isSocketConnected()) {
      toast({
        title: "Connection Error",
        description: "You are currently offline. Please check your connection.",
        variant: "destructive"
      });
      return;
    }
    
    setCallState({
      isActive: true,
      isIncoming: false,
      isVideo,
      recipientId: userId
    });
    
    // Send call request through WebSocket
    socket.send(JSON.stringify({
      type: 'call',
      payload: {
        recipientId: userId,
        isVideo
      }
    }));
  };
  
  // Handle closing a call
  const handleCloseCall = () => {
    setCallState({
      isActive: false,
      isIncoming: false,
      isVideo: false
    });
  };
  
  // Initialize audio context on user interaction
  useEffect(() => {
    const handleUserInteraction = () => {
      initAudio();
      document.removeEventListener('click', handleUserInteraction);
    };
    
    document.addEventListener('click', handleUserInteraction);
    
    return () => {
      document.removeEventListener('click', handleUserInteraction);
    };
  }, []);

  // Listen for WebSocket messages
  useEffect(() => {
    const handleSocketMessage = (event: MessageEvent) => {
      try {
        const data = JSON.parse(event.data);
        
        // Handle incoming calls
        if (data.type === 'call' && data.payload) {
          const { callerId, isVideo } = data.payload;
          
          setCallState({
            isActive: true,
            isIncoming: true,
            isVideo: isVideo || false,
            recipientId: callerId
          });
          
          // Also show a toast notification
          const caller = users.find(u => u.id === callerId);
          if (caller) {
            toast({
              title: `Incoming ${isVideo ? 'Video' : 'Voice'} Call`,
              description: `${caller.displayName || caller.username} is calling you`,
            });
          }
        }
        
        // Handle call ending
        if (data.type === 'call_end') {
          setCallState({
            isActive: false,
            isIncoming: false,
            isVideo: false
          });
          
          toast({
            title: "Call Ended",
            description: "The call has been ended",
          });
        }
        
        // Handle incoming messages
        if (data.type === 'message' && data.payload) {
          const { userId: senderId } = data.payload;
          
          // Only play sound if the message is not from the current user
          if (user && senderId !== user.id) {
            playMessageSound();
            
            // Show toast notification for the new message if not actively viewing this conversation
            if (!selectedUser || selectedUser.id !== senderId) {
              const sender = users.find(u => u.id === senderId);
              if (sender) {
                toast({
                  title: `New message from ${sender.displayName || sender.username}`,
                  description: data.payload.content.length > 30 
                    ? `${data.payload.content.substring(0, 30)}...` 
                    : data.payload.content,
                });
              }
            }
          }
        }
      } catch (error) {
        console.error('Error parsing WebSocket message:', error);
      }
    };
    
    if (socket) {
      socket.addEventListener('message', handleSocketMessage);
    }
    
    return () => {
      socket.removeEventListener('message', handleSocketMessage);
    };
  }, [toast, users, user, selectedUser]);
  
  // If no user is logged in, show a loading state
  if (!user) {
    return (
      <div className="flex items-center justify-center h-screen">
        <Loader2 className="h-8 w-8 animate-spin text-primary" />
      </div>
    );
  }
  
  // Find the recipient user for call modal
  const callRecipient = callState.recipientId 
    ? users.find(u => u.id === callState.recipientId) || null 
    : null;
  
  return (
    <div className="flex h-screen overflow-hidden">
      {/* Sidebar for direct message contacts */}
      <div className="w-80 border-r flex-shrink-0 h-full">
        <DirectMessagesList 
          currentUser={user} 
          onSelectUser={handleSelectUser}
          selectedUserId={selectedUser?.id}
        />
      </div>
      
      {/* Main chat area */}
      <div className="flex-1 flex flex-col">
        {selectedUser ? (
          <DirectMessageView 
            currentUser={user} 
            recipient={selectedUser}
            onStartCall={handleStartCall}
          />
        ) : (
          <div className="flex flex-col items-center justify-center h-full text-center p-8">
            <div className="bg-primary/10 rounded-full p-5 mb-4">
              <MessageSquare className="h-10 w-10 text-primary" />
            </div>
            <h2 className="text-2xl font-bold mb-2">Your Messages</h2>
            <p className="text-muted-foreground max-w-md">
              Select a conversation from the sidebar or start a new one by clicking the plus icon.
            </p>
          </div>
        )}
      </div>
      
      {/* Call Modal */}
      <CallModal
        isOpen={callState.isActive}
        currentUser={user}
        recipient={callRecipient}
        isIncoming={callState.isIncoming}
        isVideo={callState.isVideo}
        onClose={handleCloseCall}
      />
    </div>
  );
}