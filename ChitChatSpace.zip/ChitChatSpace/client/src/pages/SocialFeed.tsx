import { useState } from "react";
import { useQuery, useMutation } from "@tanstack/react-query";
import { useAuth } from "@/hooks/use-auth";
import { queryClient } from "@/lib/queryClient";
import { PostData } from "@shared/schema";
import { useToast } from "@/hooks/use-toast";
import { Loader2, PlusSquare, ThumbsUp, MessageSquare } from "lucide-react";
import { Button } from "@/components/ui/button";
import {
  Card,
  CardContent,
  CardFooter,
  CardHeader,
} from "@/components/ui/card";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
  DialogClose,
} from "@/components/ui/dialog";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import { format } from "date-fns";

export default function SocialFeed() {
  const { user } = useAuth();
  const { toast } = useToast();
  const [isCreatingPost, setIsCreatingPost] = useState(false);
  const [newPostData, setNewPostData] = useState({
    caption: "",
    mediaUrl: "",
    mediaType: "image",
    isReel: false
  });

  // Fetch posts
  const { data: posts = [], isLoading } = useQuery<PostData[]>({
    queryKey: ['/api/posts'],
    queryFn: async () => {
      const response = await fetch('/api/posts');
      if (!response.ok) {
        throw new Error('Failed to fetch posts');
      }
      return response.json();
    },
  });

  // Create a new post
  const createPostMutation = useMutation({
    mutationFn: async (postData: typeof newPostData) => {
      const response = await fetch('/api/posts', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify(postData),
      });
      
      if (!response.ok) {
        const errorData = await response.json();
        throw new Error(errorData.error || 'Failed to create post');
      }
      
      return response.json();
    },
    onSuccess: () => {
      // Invalidate and refetch posts
      queryClient.invalidateQueries({ queryKey: ['/api/posts'] });
      
      // Reset form and close dialog
      setNewPostData({
        caption: "",
        mediaUrl: "",
        mediaType: "image",
        isReel: false
      });
      setIsCreatingPost(false);
      
      toast({
        title: "Post Created",
        description: "Your post has been created successfully!",
      });
    },
    onError: (error: Error) => {
      toast({
        title: "Error",
        description: error.message,
        variant: "destructive",
      });
    },
  });

  // Handle form submission
  const handleCreatePost = (e: React.FormEvent) => {
    e.preventDefault();
    
    if (!newPostData.mediaUrl) {
      toast({
        title: "Error",
        description: "Please provide a media URL for your post",
        variant: "destructive",
      });
      return;
    }
    
    createPostMutation.mutate(newPostData);
  };

  if (!user) {
    return (
      <div className="flex items-center justify-center min-h-screen">
        <Loader2 className="h-8 w-8 animate-spin text-primary" />
      </div>
    );
  }

  return (
    <div className="container mx-auto py-8">
      <div className="flex justify-between items-center mb-8">
        <h1 className="text-3xl font-bold">Feed</h1>
        <Dialog open={isCreatingPost} onOpenChange={setIsCreatingPost}>
          <DialogTrigger asChild>
            <Button>
              <PlusSquare className="mr-2 h-4 w-4" />
              Create Post
            </Button>
          </DialogTrigger>
          <DialogContent className="sm:max-w-[500px]">
            <form onSubmit={handleCreatePost}>
              <DialogHeader>
                <DialogTitle>Create a new post</DialogTitle>
                <DialogDescription>
                  Share a photo or video with your followers.
                </DialogDescription>
              </DialogHeader>
              <div className="grid gap-4 py-4">
                <div className="grid grid-cols-4 items-center gap-4">
                  <Label htmlFor="mediaUrl" className="text-right">
                    Media URL
                  </Label>
                  <Input
                    id="mediaUrl"
                    value={newPostData.mediaUrl}
                    onChange={(e) => setNewPostData({ ...newPostData, mediaUrl: e.target.value })}
                    placeholder="https://example.com/image.jpg"
                    className="col-span-3"
                    required
                  />
                </div>
                <div className="grid grid-cols-4 items-center gap-4">
                  <Label htmlFor="mediaType" className="text-right">
                    Media Type
                  </Label>
                  <select
                    id="mediaType"
                    value={newPostData.mediaType}
                    onChange={(e) => setNewPostData({ ...newPostData, mediaType: e.target.value })}
                    className="flex h-10 w-full rounded-md border border-input bg-background px-3 py-2 text-sm ring-offset-background file:border-0 file:bg-transparent file:text-sm file:font-medium placeholder:text-muted-foreground focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring focus-visible:ring-offset-2 disabled:cursor-not-allowed disabled:opacity-50 col-span-3"
                  >
                    <option value="image">Image</option>
                    <option value="video">Video</option>
                  </select>
                </div>
                <div className="grid grid-cols-4 items-center gap-4">
                  <Label htmlFor="isReel" className="text-right">
                    Is Reel
                  </Label>
                  <input
                    id="isReel"
                    type="checkbox"
                    checked={newPostData.isReel}
                    onChange={(e) => setNewPostData({ ...newPostData, isReel: e.target.checked })}
                    className="ml-2 h-4 w-4"
                  />
                </div>
                <div className="grid grid-cols-4 items-center gap-4">
                  <Label htmlFor="caption" className="text-right">
                    Caption
                  </Label>
                  <Textarea
                    id="caption"
                    value={newPostData.caption}
                    onChange={(e) => setNewPostData({ ...newPostData, caption: e.target.value })}
                    placeholder="Write a caption..."
                    className="col-span-3"
                  />
                </div>
              </div>
              <DialogFooter>
                <Button type="submit" disabled={createPostMutation.isPending}>
                  {createPostMutation.isPending ? (
                    <>
                      <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                      Creating...
                    </>
                  ) : (
                    "Create Post"
                  )}
                </Button>
              </DialogFooter>
            </form>
          </DialogContent>
        </Dialog>
      </div>

      {isLoading ? (
        <div className="flex justify-center my-12">
          <Loader2 className="h-12 w-12 animate-spin text-primary" />
        </div>
      ) : posts.length === 0 ? (
        <div className="text-center py-12">
          <h2 className="text-2xl font-semibold mb-4">No posts yet</h2>
          <p className="text-muted-foreground mb-6">Be the first to create a post!</p>
          <Button onClick={() => setIsCreatingPost(true)}>
            <PlusSquare className="mr-2 h-4 w-4" />
            Create Post
          </Button>
        </div>
      ) : (
        <div className="grid grid-cols-1 gap-6 md:grid-cols-2 lg:grid-cols-3">
          {posts.map((post) => (
            <Card key={post.id} className="overflow-hidden">
              <CardHeader className="p-4">
                <div className="flex items-center gap-3">
                  <Avatar>
                    <AvatarImage src={post.user.profilePicture} alt={post.user.displayName} />
                    <AvatarFallback>{post.user.displayName.substring(0, 2).toUpperCase()}</AvatarFallback>
                  </Avatar>
                  <div>
                    <div className="font-semibold">{post.user.displayName}</div>
                    <div className="text-sm text-muted-foreground">@{post.user.username}</div>
                  </div>
                </div>
              </CardHeader>
              <CardContent className="p-0">
                {post.mediaType === 'image' ? (
                  <img
                    src={post.mediaUrl}
                    alt={post.caption || 'Post image'}
                    className="w-full h-auto object-cover"
                    style={{ maxHeight: '400px' }}
                  />
                ) : (
                  <video
                    src={post.mediaUrl}
                    controls
                    className="w-full h-auto"
                    style={{ maxHeight: '400px' }}
                  />
                )}
                {post.caption && (
                  <div className="p-4">
                    <p>{post.caption}</p>
                  </div>
                )}
              </CardContent>
              <CardFooter className="flex justify-between p-4">
                <div className="flex items-center gap-4">
                  <Button variant="ghost" className="flex items-center gap-1 px-2">
                    <ThumbsUp className="h-4 w-4" />
                    <span>{post.likes || 0}</span>
                  </Button>
                  <Button variant="ghost" className="flex items-center gap-1 px-2">
                    <MessageSquare className="h-4 w-4" />
                    <span>{post.comments || 0}</span>
                  </Button>
                </div>
                <div className="text-sm text-muted-foreground">
                  {format(new Date(post.timestamp), 'MMM d, yyyy')}
                </div>
              </CardFooter>
            </Card>
          ))}
        </div>
      )}
    </div>
  );
}