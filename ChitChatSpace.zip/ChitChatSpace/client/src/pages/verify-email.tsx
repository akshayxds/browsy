import { useState, useEffect } from "react";
import { useToast } from "@/hooks/use-toast";
import { Loader2, CheckCircle, XCircle } from "lucide-react";
import { Button } from "@/components/ui/button";
import { useLocation } from "wouter";

export default function VerifyEmailPage() {
  const [location, setLocation] = useLocation();
  const { toast } = useToast();
  
  // Extract token from URL manually
  const searchParams = new URLSearchParams(window.location.search);
  const token = searchParams.get("token");
  
  const [status, setStatus] = useState<"loading" | "success" | "error">("loading");
  const [message, setMessage] = useState<string>("");

  useEffect(() => {
    // If no token is provided, redirect to auth page
    if (!token) {
      toast({
        title: "Missing token",
        description: "No verification token provided.",
        variant: "destructive",
      });
      setLocation("/auth");
      return;
    }

    // Verify the email
    const verifyEmail = async () => {
      try {
        const response = await fetch(`/api/verify-email?token=${token}`);
        const data = await response.json();

        if (response.ok) {
          setStatus("success");
          setMessage(data.message || "Your email has been verified successfully!");
          
          toast({
            title: "Email verified",
            description: "Your email has been verified successfully!",
          });
        } else {
          setStatus("error");
          setMessage(data.error || "Failed to verify your email. The link may be invalid or expired.");
          
          toast({
            title: "Verification failed",
            description: data.error || "Failed to verify your email.",
            variant: "destructive",
          });
        }
      } catch (error) {
        setStatus("error");
        setMessage("An error occurred while verifying your email.");
        
        toast({
          title: "Verification error",
          description: "An error occurred while verifying your email.",
          variant: "destructive",
        });
      }
    };

    verifyEmail();
  }, [token, toast, setLocation]);

  return (
    <div className="min-h-screen bg-gradient-to-b from-indigo-50 to-white flex flex-col justify-center items-center px-4 sm:px-6 lg:px-8">
      <div className="w-full max-w-md p-8 space-y-8 bg-white rounded-xl shadow-lg">
        <div className="text-center">
          <h1 className="text-3xl font-extrabold tracking-tight">
            Email Verification
          </h1>
          <p className="mt-2 text-sm text-gray-600">
            {status === "loading" ? "Verifying your email address..." : ""}
          </p>
        </div>

        <div className="flex flex-col items-center justify-center space-y-4">
          {status === "loading" && (
            <div className="flex flex-col items-center space-y-4">
              <Loader2 className="h-16 w-16 text-indigo-500 animate-spin" />
              <p className="text-gray-600">Processing your verification request...</p>
            </div>
          )}

          {status === "success" && (
            <div className="flex flex-col items-center space-y-4">
              <CheckCircle className="h-16 w-16 text-green-500" />
              <p className="text-center text-gray-700">{message}</p>
            </div>
          )}

          {status === "error" && (
            <div className="flex flex-col items-center space-y-4">
              <XCircle className="h-16 w-16 text-red-500" />
              <p className="text-center text-gray-700">{message}</p>
            </div>
          )}

          <div className="mt-6">
            {status !== "loading" && (
              <Button 
                onClick={() => setLocation("/")}
                className="w-full"
              >
                Continue to App
              </Button>
            )}
          </div>
        </div>
      </div>
    </div>
  );
}