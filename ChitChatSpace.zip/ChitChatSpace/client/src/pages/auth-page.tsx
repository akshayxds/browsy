import { useEffect, useState } from "react";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { useToast } from "@/hooks/use-toast";
import { Redirect } from "wouter";
import { z } from "zod";
import { useAuth } from "@/hooks/use-auth";

// UI Components
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Label } from "@/components/ui/label";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import { Loader2 } from "lucide-react";

// Validation schemas
const loginSchema = z.object({
  email: z.string().email("Invalid email address"),
  password: z.string().min(1, "Password is required"),
});

const registerSchema = z.object({
  username: z.string().min(3, "Username must be at least 3 characters"),
  email: z.string().email("Invalid email address"),
  password: z.string().min(8, "Password must be at least 8 characters"),
  confirmPassword: z.string()
}).refine(data => data.password === data.confirmPassword, {
  message: "Passwords don't match",
  path: ["confirmPassword"],
});

type LoginFormValues = z.infer<typeof loginSchema>;
type RegisterFormValues = z.infer<typeof registerSchema>;

export default function AuthPage() {
  const [activeTab, setActiveTab] = useState("login");
  const [showVerificationMessage, setShowVerificationMessage] = useState(false);
  const [verificationEmail, setVerificationEmail] = useState("");
  const { toast } = useToast();
  const { user, loginMutation, registerMutation, isLoading } = useAuth();

  // Setup login form
  const loginForm = useForm<LoginFormValues>({
    resolver: zodResolver(loginSchema),
    defaultValues: {
      email: "",
      password: ""
    }
  });

  // Setup registration form
  const registerForm = useForm<RegisterFormValues>({
    resolver: zodResolver(registerSchema),
    defaultValues: {
      username: "",
      email: "",
      password: "",
      confirmPassword: ""
    }
  });

  // Handle login form submission
  const onLoginSubmit = (data: LoginFormValues) => {
    loginMutation.mutate(data);
  };

  // Handle registration form submission
  const onRegisterSubmit = (data: RegisterFormValues) => {
    // Save email to show in verification message
    setVerificationEmail(data.email);
    
    // Send the whole data object including confirmPassword
    registerMutation.mutate(data);
  };
  
  // Show verification message when registration succeeds with emailVerificationSent flag
  useEffect(() => {
    if (registerMutation.isSuccess && registerMutation.data?.emailVerificationSent) {
      setShowVerificationMessage(true);
      toast({
        title: "Verification email sent",
        description: `We've sent a verification email to ${verificationEmail}. Please check your inbox.`,
      });
    }
  }, [registerMutation.isSuccess, registerMutation.data, verificationEmail, toast]);

  // Reset forms when changing tabs
  useEffect(() => {
    if (activeTab === "login") {
      registerForm.reset();
    } else {
      loginForm.reset();
    }
  }, [activeTab, loginForm, registerForm]);

  // If user is already logged in, redirect to home
  if (user) {
    return <Redirect to="/" />;
  }

  return (
    <div className="min-h-screen grid md:grid-cols-2 bg-background">
      {/* Login & Registration Form */}
      <div className="flex items-center justify-center p-4 md:p-10">
        <div className="max-w-md w-full">
          <div className="space-y-2 text-center mb-8">
            <h1 className="text-3xl font-bold tracking-tight text-foreground bg-gradient-to-r from-primary to-purple-600 text-transparent bg-clip-text">
              Browsy
            </h1>
            <p className="text-muted-foreground">
              Connect with friends and family instantly
            </p>
          </div>

          {showVerificationMessage ? (
            <div className="bg-green-50 border border-green-200 rounded-lg p-4 mb-6">
              <div className="flex">
                <div className="flex-shrink-0">
                  <svg className="h-5 w-5 text-green-400" viewBox="0 0 20 20" fill="currentColor">
                    <path fillRule="evenodd" d="M10 18a8 8 0 100-16 8 8 0 000 16zm3.707-9.293a1 1 0 00-1.414-1.414L9 10.586 7.707 9.293a1 1 0 00-1.414 1.414l2 2a1 1 0 001.414 0l4-4z" clipRule="evenodd" />
                  </svg>
                </div>
                <div className="ml-3">
                  <h3 className="text-sm font-medium text-green-800">Verification email sent</h3>
                  <div className="mt-2 text-sm text-green-700">
                    <p>Please check your inbox at <span className="font-semibold">{verificationEmail}</span> and click the verification link.</p>
                  </div>
                  <div className="mt-4">
                    <Button 
                      variant="ghost" 
                      size="sm"
                      onClick={() => setShowVerificationMessage(false)}
                      className="text-green-700 hover:bg-green-100"
                    >
                      Got it
                    </Button>
                  </div>
                </div>
              </div>
            </div>
          ) : (
            <Tabs defaultValue="login" value={activeTab} onValueChange={setActiveTab}>
              <TabsList className="grid grid-cols-2 w-full mb-6">
                <TabsTrigger value="login">Login</TabsTrigger>
                <TabsTrigger value="register">Register</TabsTrigger>
              </TabsList>

            {/* Login Form */}
            <TabsContent value="login">
              <Card>
                <CardHeader>
                  <CardTitle>Login</CardTitle>
                  <CardDescription>
                    Enter your email and password to access your account
                  </CardDescription>
                </CardHeader>
                <form onSubmit={loginForm.handleSubmit(onLoginSubmit)}>
                  <CardContent className="space-y-4">
                    <div className="space-y-2">
                      <Label htmlFor="email">Email</Label>
                      <Input
                        id="email"
                        type="email"
                        placeholder="your@email.com"
                        disabled={loginMutation.isPending}
                        {...loginForm.register("email")}
                      />
                      {loginForm.formState.errors.email && (
                        <p className="text-sm text-destructive">
                          {loginForm.formState.errors.email.message}
                        </p>
                      )}
                    </div>

                    <div className="space-y-2">
                      <div className="flex items-center justify-between">
                        <Label htmlFor="password">Password</Label>
                      </div>
                      <Input
                        id="password"
                        type="password"
                        disabled={loginMutation.isPending}
                        {...loginForm.register("password")}
                      />
                      {loginForm.formState.errors.password && (
                        <p className="text-sm text-destructive">
                          {loginForm.formState.errors.password.message}
                        </p>
                      )}
                    </div>
                  </CardContent>
                  <CardFooter>
                    <Button
                      type="submit"
                      className="w-full"
                      disabled={loginMutation.isPending}
                    >
                      {loginMutation.isPending ? (
                        <>
                          <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                          Logging in...
                        </>
                      ) : (
                        "Login"
                      )}
                    </Button>
                  </CardFooter>
                </form>
              </Card>
            </TabsContent>

            {/* Registration Form */}
            <TabsContent value="register">
              <Card>
                <CardHeader>
                  <CardTitle>Create an account</CardTitle>
                  <CardDescription>
                    Enter your details to create a new account
                  </CardDescription>
                </CardHeader>
                <form onSubmit={registerForm.handleSubmit(onRegisterSubmit)}>
                  <CardContent className="space-y-4">
                    <div className="space-y-2">
                      <Label htmlFor="username">Username</Label>
                      <Input
                        id="username"
                        placeholder="johndoe"
                        disabled={registerMutation.isPending}
                        {...registerForm.register("username")}
                      />
                      {registerForm.formState.errors.username && (
                        <p className="text-sm text-destructive">
                          {registerForm.formState.errors.username.message}
                        </p>
                      )}
                    </div>

                    <div className="space-y-2">
                      <Label htmlFor="registerEmail">Email</Label>
                      <Input
                        id="registerEmail"
                        type="email"
                        placeholder="your@email.com"
                        disabled={registerMutation.isPending}
                        {...registerForm.register("email")}
                      />
                      {registerForm.formState.errors.email && (
                        <p className="text-sm text-destructive">
                          {registerForm.formState.errors.email.message}
                        </p>
                      )}
                    </div>

                    <div className="space-y-2">
                      <Label htmlFor="registerPassword">Password</Label>
                      <Input
                        id="registerPassword"
                        type="password"
                        disabled={registerMutation.isPending}
                        {...registerForm.register("password")}
                      />
                      {registerForm.formState.errors.password && (
                        <p className="text-sm text-destructive">
                          {registerForm.formState.errors.password.message}
                        </p>
                      )}
                    </div>

                    <div className="space-y-2">
                      <Label htmlFor="confirmPassword">Confirm Password</Label>
                      <Input
                        id="confirmPassword"
                        type="password"
                        disabled={registerMutation.isPending}
                        {...registerForm.register("confirmPassword")}
                      />
                      {registerForm.formState.errors.confirmPassword && (
                        <p className="text-sm text-destructive">
                          {registerForm.formState.errors.confirmPassword.message}
                        </p>
                      )}
                    </div>
                  </CardContent>
                  <CardFooter>
                    <Button
                      type="submit"
                      className="w-full"
                      disabled={registerMutation.isPending}
                    >
                      {registerMutation.isPending ? (
                        <>
                          <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                          Creating account...
                        </>
                      ) : (
                        "Create Account"
                      )}
                    </Button>
                  </CardFooter>
                </form>
              </Card>
            </TabsContent>
          </Tabs>
          )}
        </div>
      </div>

      {/* Hero section */}
      <div className="hidden md:flex flex-col items-center justify-center p-10 bg-gradient-to-br from-primary/5 to-primary/30">
        <div className="max-w-lg text-center space-y-8">
          <div className="space-y-4">
            <h2 className="text-4xl font-bold text-foreground">
              Modern chat experience for everyone
            </h2>
            <p className="text-lg text-muted-foreground">
              Browsy provides a familiar chat experience without requiring a phone number. Just use your email to sign up and start chatting immediately.
            </p>
          </div>

          <div className="grid grid-cols-3 gap-4">
            <div className="bg-card p-4 rounded-lg shadow">
              <h3 className="font-medium mb-2">Simple</h3>
              <p className="text-sm text-muted-foreground">Clean interface that's easy to use</p>
            </div>
            <div className="bg-card p-4 rounded-lg shadow">
              <h3 className="font-medium mb-2">Secure</h3>
              <p className="text-sm text-muted-foreground">Email-based verification keeps your account safe</p>
            </div>
            <div className="bg-card p-4 rounded-lg shadow">
              <h3 className="font-medium mb-2">Fast</h3>
              <p className="text-sm text-muted-foreground">Real-time messaging with instant delivery</p>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}