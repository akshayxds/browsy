// Simple audio utility for playing notification sounds

// Create an audio context
const AudioContext = window.AudioContext || (window as any).webkitAudioContext;
let audioContext: AudioContext | null = null;

// Initialize audio context on user interaction
export function initAudio() {
  if (!audioContext) {
    audioContext = new AudioContext();
  }
  return audioContext;
}

// Base64 encoded notification sound (short, subtle "ping" sound)
const notificationSoundBase64 = 'data:audio/mp3;base64,SUQzBAAAAAAAI1RTU0UAAAAPAAADTGF2ZjU4Ljc2LjEwMAAAAAAAAAAAAAAA//tAwAAAAAAAAAAAAAAAAAAAAAAASW5mbwAAAA8AAAASAAAeMwAUFBQUFCgUFBQUFDMzMzMzM0dHR0dHR1xHR0dHR0dwcHBwcHCFcHBwcHCPj4+Pj4+kj4+Pj4+4uLi4uLjMuLi4uLjh4eHh4eH24eHh4eHh//////////////////////////////////////////////////////////////////8AAAAATGF2YzU4LjEzAAAAAAAAAAAAAAAAJAUHAQAAAAAAHjOZTf9/AAAAAAAAAAAAAAAA//tAwAAABLBNQ3BAAgAtYV3+MBAAqQS9PNb5mCZzTu4QlQ4IGBOBy9ptJqxvxMcqFAXKYeK03SBgYBECgUSvnM5eNGggJggkBFPzwSdXMJv5JpLlRc5yM3WkUOkiRZGQmI5v7k3///8VK4CEe7MW9fRVAoKnCFFFBQUFRUUFd5Q2aVUl////////////+UpZZhioqNBUoKIyveuXzt0YBAyKC4wFAkJMNAMLzGveHyEYNPCgVFRWMgHBIJxXf////5b/6GNEI4RY7oxUVzeO9XigwDAcOh0dCluAgAwDAvM2LdRocHhwcHB3////eWgaB4Pn/////////////1K5CpFgIRqJBljiESzWNRzHWejUThaFrBRiKhYRCpJW3////1f/bp8IiYRAiIeGRMlFSL//////////////////e1ZXRETE4pE4okIiIiakREZEQiIiIiM31qfqQiIiIiIf/////b/////////////+9JEQiREQiREQiJERCJERETf/////t///////////////+37URERE4qQiJVt////////t//////2/XXou1qKiIiIiIiIiIiIiJ//tAwI4AEIWtNfzwAAPKNaS/ngAAUzMzMzMzMzMzR//MzMzMzMzMzMzMzMzMzMzMzMzMzMzMzMzMzMzMzMzMzMzMzMzMzMzMzMzMzMzMzMzMzMzMzMzMzMzMzMzMzMzMzMzMzMzMzMzMzMzMzMzMzMzMzMzMzMzMzMzMzMzMzMzMzMzMzMzMzMzMzMzMzMzMzMzMzMzMzMzMzMzMzMzMzMzMzMzMzMzMzMzMzMzMzMzMzMzMzMzMzMzMzMzMzMzMzMzMzMzMzMzMzMzMzMzMzMzMzMzMzMzMzMzMzMzMzMzMzMzMzMzMzMzMzMzMzMzMzMzMzMzMzMzMzMzMzMzMzMzMzMzMzMzMzMzMzMzMzMzMzMzMzMzMzMzMzMzMzMzMzMzMzM=';

// Function to play the notification sound
export function playNotificationSound() {
  try {
    // Initialize context if needed
    initAudio();
    
    if (!audioContext) return;
    
    // Use standard Audio API for simplicity
    const audio = new Audio(notificationSoundBase64);
    audio.volume = 0.5; // Set volume to 50%
    audio.play().catch(err => {
      console.warn('Failed to play notification sound:', err);
    });
  } catch (error) {
    console.error('Error playing notification sound:', error);
  }
}

// Function to play sound when a new message arrives
export function playMessageSound() {
  playNotificationSound();
}