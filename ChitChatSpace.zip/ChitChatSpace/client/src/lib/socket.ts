// Create a WebSocket connection to the server
const protocol = window.location.protocol === "https:" ? "wss:" : "ws:";
const host = window.location.host;
export const socket = new WebSocket(`${protocol}//${host}/ws`);

// Track socket connection status
let socketConnected = false;

// Set up event listeners for the WebSocket connection
socket.addEventListener('open', () => {
  console.log('WebSocket connection established');
  socketConnected = true;
});

socket.addEventListener('close', () => {
  console.log('WebSocket connection closed');
  socketConnected = false;
});

socket.addEventListener('error', (error) => {
  console.error('WebSocket error:', error);
  socketConnected = false;
});

// Helper function to check if the socket is connected
export function isSocketConnected(): boolean {
  return socketConnected && socket.readyState === WebSocket.OPEN;
}

// Helper function to reconnect the socket
export function reconnectSocket(): void {
  if (socket.readyState === WebSocket.CLOSED) {
    const newProtocol = window.location.protocol === "https:" ? "wss:" : "ws:";
    const newSocket = new WebSocket(`${newProtocol}//${host}/ws`);
    
    // Replace the old socket with the new one
    Object.assign(socket, newSocket);
    
    newSocket.addEventListener('open', () => {
      console.log('WebSocket connection re-established');
      socketConnected = true;
    });
  }
}

// Set up automatic reconnection attempts
setInterval(() => {
  if (!isSocketConnected()) {
    console.log('Attempting to reconnect WebSocket...');
    reconnectSocket();
  }
}, 5000); // Try to reconnect every 5 seconds if disconnected