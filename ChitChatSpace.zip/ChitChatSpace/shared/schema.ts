import { pgTable, text, serial, integer, boolean, timestamp, jsonb } from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod";

export const users = pgTable("users", {
  id: serial("id").primaryKey(),
  username: text("username").notNull().unique(),
  email: text("email").notNull().unique(),
  password: text("password").notNull(),
  displayName: text("display_name").notNull(),
  initials: text("initials").notNull(),
  color: text("color").notNull(),
  status: text("status").notNull().default("offline"),
  emailVerified: boolean("email_verified").notNull().default(false),
  profilePicture: text("profile_picture"),
  bio: text("bio"),
});

export const channels = pgTable("channels", {
  id: serial("id").primaryKey(),
  name: text("name").notNull(),
  type: text("type").notNull().default("channel"),
  unreadCount: integer("unread_count").notNull().default(0),
  creatorId: integer("creator_id").notNull(),
  picture: text("picture"),
  description: text("description"),
});

// Channel members with roles (admin, moderator, member)
export const channelMembers = pgTable("channel_members", {
  id: serial("id").primaryKey(),
  channelId: integer("channel_id").notNull(),
  userId: integer("user_id").notNull(),
  role: text("role").notNull().default("member"),
});

export const messages = pgTable("messages", {
  id: serial("id").primaryKey(),
  content: text("content").notNull(),
  userId: integer("user_id").notNull(),
  channelId: integer("channel_id"),
  recipientId: integer("recipient_id"),
  isDirectMessage: boolean("is_direct_message").notNull().default(false),
  timestamp: timestamp("timestamp").notNull().defaultNow(),
  attachments: jsonb("attachments"),
  read: boolean("read").notNull().default(false),
});

// Call records for voice and video calls
export const calls = pgTable("calls", {
  id: serial("id").primaryKey(),
  callerId: integer("caller_id").notNull(),
  receiverId: integer("receiver_id"),
  channelId: integer("channel_id"),
  isGroupCall: boolean("is_group_call").notNull().default(false),
  isVideoCall: boolean("is_video_call").notNull().default(false),
  startTime: timestamp("start_time").notNull().defaultNow(),
  endTime: timestamp("end_time"),
  status: text("status").notNull().default("missed"), // "ongoing", "completed", "missed", "rejected"
});

// Social media content (posts and reels)
export const posts = pgTable("posts", {
  id: serial("id").primaryKey(),
  userId: integer("user_id").notNull(),
  caption: text("caption"),
  mediaUrl: text("media_url").notNull(),
  mediaType: text("media_type").notNull().default("image"), // "image", "video"
  isReel: boolean("is_reel").notNull().default(false),
  timestamp: timestamp("timestamp").notNull().defaultNow(),
  likes: integer("likes").notNull().default(0),
  comments: integer("comments").notNull().default(0),
});

// Comments on posts
export const comments = pgTable("comments", {
  id: serial("id").primaryKey(),
  postId: integer("post_id").notNull(),
  userId: integer("user_id").notNull(),
  content: text("content").notNull(),
  timestamp: timestamp("timestamp").notNull().defaultNow(),
});

export const insertUserSchema = createInsertSchema(users).pick({
  username: true,
  email: true,
  password: true,
  displayName: true,
  initials: true,
  color: true,
  status: true,
  emailVerified: true,
  profilePicture: true,
  bio: true,
});

export const insertChannelSchema = createInsertSchema(channels).pick({
  name: true,
  type: true,
  creatorId: true,
  picture: true,
  description: true,
});

export const insertChannelMemberSchema = createInsertSchema(channelMembers).pick({
  channelId: true,
  userId: true,
  role: true,
});

export const insertMessageSchema = createInsertSchema(messages).pick({
  content: true,
  userId: true,
  channelId: true,
  recipientId: true,
  isDirectMessage: true,
  attachments: true,
  read: true,
});

export const insertCallSchema = createInsertSchema(calls).pick({
  callerId: true,
  receiverId: true,
  channelId: true,
  isGroupCall: true,
  isVideoCall: true,
  status: true,
});

export const insertPostSchema = createInsertSchema(posts).pick({
  userId: true,
  caption: true,
  mediaUrl: true,
  mediaType: true,
  isReel: true,
});

export const insertCommentSchema = createInsertSchema(comments).pick({
  postId: true,
  userId: true,
  content: true,
});

export type InsertUser = z.infer<typeof insertUserSchema>;
export type User = typeof users.$inferSelect;
export type InsertChannel = z.infer<typeof insertChannelSchema>;
export type Channel = typeof channels.$inferSelect;
export type InsertChannelMember = z.infer<typeof insertChannelMemberSchema>;
export type ChannelMember = typeof channelMembers.$inferSelect;
export type InsertMessage = z.infer<typeof insertMessageSchema>;
export type Message = typeof messages.$inferSelect;
export type InsertCall = z.infer<typeof insertCallSchema>;
export type Call = typeof calls.$inferSelect;
export type InsertPost = z.infer<typeof insertPostSchema>;
export type Post = typeof posts.$inferSelect;
export type InsertComment = z.infer<typeof insertCommentSchema>;
export type Comment = typeof comments.$inferSelect;

// Auth schemas for registration and login
export const registerSchema = z.object({
  username: z.string().min(3, "Username must be at least 3 characters"),
  email: z.string().email("Invalid email address"),
  password: z.string().min(8, "Password must be at least 8 characters"),
  confirmPassword: z.string()
}).refine(data => data.password === data.confirmPassword, {
  message: "Passwords don't match",
  path: ["confirmPassword"],
});

export const loginSchema = z.object({
  email: z.string().email("Invalid email address"),
  password: z.string().min(1, "Password is required"),
});

export type RegisterInput = z.infer<typeof registerSchema>;
export type LoginInput = z.infer<typeof loginSchema>;

// Client types for WebSocket messages
export type SocketMessage = {
  type: 'message' | 'typing' | 'status' | 'call' | 'call_response' | 'call_end';
  payload: any;
};

export type ChatMessage = {
  id: number;
  content: string;
  userId: number;
  channelId?: number;
  recipientId?: number;
  isDirectMessage: boolean;
  timestamp: string;
  attachments?: any;
  read: boolean;
  user: {
    username: string;
    displayName: string;
    initials: string;
    color: string;
    profilePicture?: string;
  };
};

export type CallData = {
  id: number;
  callerId: number;
  receiverId?: number;
  channelId?: number;
  isGroupCall: boolean;
  isVideoCall: boolean;
  status: string;
  caller: {
    username: string;
    displayName: string;
    initials: string;
    profilePicture?: string;
  };
};

export type PostData = {
  id: number;
  userId: number;
  caption?: string;
  mediaUrl: string;
  mediaType: string;
  isReel: boolean;
  timestamp: string;
  likes: number;
  comments: number;
  user: {
    username: string;
    displayName: string;
    profilePicture?: string;
  };
};

export type CommentData = {
  id: number;
  postId: number;
  userId: number;
  content: string;
  timestamp: string;
  user: {
    username: string;
    displayName: string;
    profilePicture?: string;
  };
};
