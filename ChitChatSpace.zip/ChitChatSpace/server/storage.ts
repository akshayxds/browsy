import { 
  users, type User, type InsertUser,
  channels, type Channel, type InsertChannel,
  channelMembers, type ChannelMember, type InsertChannelMember,
  messages, type Message, type InsertMessage,
  calls, type Call, type InsertCall,
  posts, type Post, type InsertPost,
  comments, type Comment, type InsertComment
} from "@shared/schema";
import { db } from "./db";
import { eq, asc, and, or, isNull, desc, sql } from "drizzle-orm";
import session from "express-session";
import connectPgSimple from "connect-pg-simple";

// Create the PostgreSQL session store
const PostgresSessionStore = connectPgSimple(session);

export interface IStorage {
  // User methods
  getUser(id: number): Promise<User | undefined>;
  getUserByUsername(username: string): Promise<User | undefined>;
  getUserByEmail(email: string): Promise<User | undefined>;
  createUser(user: InsertUser): Promise<User>;
  updateUserStatus(id: number, status: string): Promise<User | undefined>;
  updateUserEmailVerification(id: number, verified: boolean): Promise<User | undefined>;
  updateUserProfile(id: number, profileData: Partial<User>): Promise<User | undefined>;
  getAllUsers(): Promise<User[]>;
  
  // Channel methods
  getChannel(id: number): Promise<Channel | undefined>;
  getChannelByName(name: string): Promise<Channel | undefined>;
  createChannel(channel: InsertChannel): Promise<Channel>;
  updateChannel(id: number, channelData: Partial<Channel>): Promise<Channel | undefined>;
  getAllChannels(): Promise<Channel[]>;
  getUserChannels(userId: number): Promise<Channel[]>;
  
  // Channel members
  getChannelMembers(channelId: number): Promise<ChannelMember[]>;
  addChannelMember(member: InsertChannelMember): Promise<ChannelMember>;
  removeChannelMember(channelId: number, userId: number): Promise<boolean>;
  updateChannelMemberRole(channelId: number, userId: number, role: string): Promise<ChannelMember | undefined>;
  
  // Message methods
  getMessage(id: number): Promise<Message | undefined>;
  createMessage(message: InsertMessage): Promise<Message>;
  getMessagesByChannel(channelId: number): Promise<Message[]>;
  getDirectMessages(userId: number, recipientId: number): Promise<Message[]>;
  getConversationPartners(userId: number): Promise<number[]>;
  markMessageAsRead(messageId: number): Promise<Message | undefined>;
  
  // Call methods
  createCall(call: InsertCall): Promise<Call>;
  getCall(id: number): Promise<Call | undefined>;
  updateCallStatus(id: number, status: string): Promise<Call | undefined>;
  updateCallEnd(id: number): Promise<Call | undefined>;
  getUserCalls(userId: number): Promise<Call[]>;
  
  // Social media methods - Posts
  createPost(post: InsertPost): Promise<Post>;
  getPost(id: number): Promise<Post | undefined>;
  getUserPosts(userId: number): Promise<Post[]>;
  getFeedPosts(): Promise<Post[]>;
  deletePost(id: number): Promise<boolean>;
  
  // Social media methods - Comments
  createComment(comment: InsertComment): Promise<Comment>;
  getPostComments(postId: number): Promise<Comment[]>;
  deleteComment(id: number): Promise<boolean>;
  
  // Session store
  sessionStore: session.Store;
}

// Database implementation
export class DatabaseStorage implements IStorage {
  sessionStore: session.Store;
  
  constructor() {
    // Create session store
    this.sessionStore = new PostgresSessionStore({
      conString: process.env.DATABASE_URL,
      createTableIfMissing: true
    });
    
    // Initialize database with sample data
    this.initializeDatabase();
  }
  
  private async initializeDatabase() {
    try {
      // Check if we already have users
      const existingUsers = await db.select().from(users).limit(1);
      
      if (existingUsers.length === 0) {
        console.log('Initializing database with sample data...');
        
        // First create the admin user who will be the creator of the channels
        const [admin] = await db.insert(users).values({
          username: 'admin',
          email: 'admin@browsy.com',
          password: 'password',
          displayName: 'System Admin',
          initials: 'SA',
          color: '#FF5733',
          status: 'online',
          emailVerified: true
        }).returning();
        
        // Create default channels
        await db.insert(channels).values([
          { name: 'general', type: 'channel', creatorId: admin.id },
          { name: 'random', type: 'channel', creatorId: admin.id },
          { name: 'help', type: 'channel', creatorId: admin.id }
        ]);
        
        // Get created channels
        const channelsList = await db.select().from(channels);
        
        // Create sample users
        const initialUsers = [
          { 
            username: 'me',
            email: 'me@example.com',
            password: 'password', 
            displayName: 'Me', 
            initials: 'ME',
            color: '#6366F1',
            status: 'online',
            emailVerified: true
          },
          { 
            username: 'sarah',
            email: 'sarah@example.com',
            password: 'password', 
            displayName: 'Sarah Johnson', 
            initials: 'SJ',
            color: '#8B5CF6',
            status: 'online',
            emailVerified: true
          },
          { 
            username: 'mike',
            email: 'mike@example.com',
            password: 'password', 
            displayName: 'Mike Robinson', 
            initials: 'MR',
            color: '#818CF8',
            status: 'offline',
            emailVerified: true
          },
          { 
            username: 'anna',
            email: 'anna@example.com',
            password: 'password', 
            displayName: 'Anna Lee', 
            initials: 'AL',
            color: '#EC4899',
            status: 'away',
            emailVerified: true
          },
          { 
            username: 'james',
            email: 'james@example.com',
            password: 'password', 
            displayName: 'James Taylor', 
            initials: 'JT',
            color: '#60A5FA',
            status: 'online',
            emailVerified: true
          }
        ];
        
        await db.insert(users).values(initialUsers);
        
        // Add some example messages
        const usersList = await db.select().from(users);
        const generalChannel = channelsList.find((c: Channel) => c.name === 'general');
        const randomChannel = channelsList.find((c: Channel) => c.name === 'random');
        
        if (generalChannel && randomChannel && usersList.length > 0) {
          await db.insert(messages).values([
            {
              content: 'Hello everyone! Welcome to ChatSync!',
              userId: usersList[0].id,
              channelId: generalChannel.id
            },
            {
              content: 'Thanks for having me here!',
              userId: usersList[1].id,
              channelId: generalChannel.id
            },
            {
              content: 'This is a great chat interface.',
              userId: usersList[3].id,
              channelId: generalChannel.id
            },
            {
              content: 'Just joined the random channel!',
              userId: usersList[2].id,
              channelId: randomChannel.id
            },
            {
              content: 'Hello from the random channel!',
              userId: usersList[4].id,
              channelId: randomChannel.id
            }
          ]);
        }
        
        console.log('Database initialized successfully!');
      }
    } catch (error) {
      console.error('Error initializing database:', error);
    }
  }
  
  // User methods
  async getUser(id: number): Promise<User | undefined> {
    const [user] = await db.select().from(users).where(eq(users.id, id));
    return user;
  }
  
  async getUserByUsername(username: string): Promise<User | undefined> {
    const [user] = await db.select().from(users).where(eq(users.username, username));
    return user;
  }
  
  async getUserByEmail(email: string): Promise<User | undefined> {
    const [user] = await db.select().from(users).where(eq(users.email, email));
    return user;
  }
  
  async createUser(insertUser: InsertUser): Promise<User> {
    const [user] = await db.insert(users).values(insertUser).returning();
    return user;
  }
  
  async updateUserStatus(id: number, status: string): Promise<User | undefined> {
    const [user] = await db
      .update(users)
      .set({ status })
      .where(eq(users.id, id))
      .returning();
    return user;
  }
  
  async updateUserEmailVerification(id: number, verified: boolean): Promise<User | undefined> {
    const [user] = await db
      .update(users)
      .set({ emailVerified: verified })
      .where(eq(users.id, id))
      .returning();
    return user;
  }

  async updateUserProfile(id: number, profileData: Partial<User>): Promise<User | undefined> {
    const [user] = await db
      .update(users)
      .set(profileData)
      .where(eq(users.id, id))
      .returning();
    return user;
  }
  
  async getAllUsers(): Promise<User[]> {
    return await db.select().from(users);
  }
  
  // Channel methods
  async getChannel(id: number): Promise<Channel | undefined> {
    const [channel] = await db.select().from(channels).where(eq(channels.id, id));
    return channel;
  }
  
  async getChannelByName(name: string): Promise<Channel | undefined> {
    const [channel] = await db.select().from(channels).where(eq(channels.name, name));
    return channel;
  }
  
  async createChannel(insertChannel: InsertChannel): Promise<Channel> {
    const [channel] = await db
      .insert(channels)
      .values(insertChannel)
      .returning();
    return channel;
  }
  
  async updateChannel(id: number, channelData: Partial<Channel>): Promise<Channel | undefined> {
    const [channel] = await db
      .update(channels)
      .set(channelData)
      .where(eq(channels.id, id))
      .returning();
    return channel;
  }

  async getAllChannels(): Promise<Channel[]> {
    return await db.select().from(channels);
  }
  
  async getUserChannels(userId: number): Promise<Channel[]> {
    // Get all channels where the user is a member
    const memberships = await db
      .select()
      .from(channelMembers)
      .where(eq(channelMembers.userId, userId));
    
    // Get all channel IDs
    const channelIds = memberships.map(m => m.channelId);
    
    // Return empty array if user has no channels
    if (channelIds.length === 0) {
      return [];
    }
    
    // Get all channels by ID
    return await db
      .select()
      .from(channels)
      .where(
        channelIds.length === 1 
          ? eq(channels.id, channelIds[0]) 
          : or(...channelIds.map(id => eq(channels.id, id)))
      );
  }
  
  async getChannelMembers(channelId: number): Promise<ChannelMember[]> {
    return await db
      .select()
      .from(channelMembers)
      .where(eq(channelMembers.channelId, channelId));
  }
  
  async addChannelMember(member: InsertChannelMember): Promise<ChannelMember> {
    const [newMember] = await db
      .insert(channelMembers)
      .values(member)
      .returning();
    return newMember;
  }
  
  async removeChannelMember(channelId: number, userId: number): Promise<boolean> {
    const result = await db
      .delete(channelMembers)
      .where(
        and(
          eq(channelMembers.channelId, channelId),
          eq(channelMembers.userId, userId)
        )
      );
    return !!result;
  }
  
  async updateChannelMemberRole(channelId: number, userId: number, role: string): Promise<ChannelMember | undefined> {
    const [updated] = await db
      .update(channelMembers)
      .set({ role })
      .where(
        and(
          eq(channelMembers.channelId, channelId),
          eq(channelMembers.userId, userId)
        )
      )
      .returning();
    return updated;
  }
  
  // Message methods
  async getMessage(id: number): Promise<Message | undefined> {
    const [message] = await db.select().from(messages).where(eq(messages.id, id));
    return message;
  }
  
  async createMessage(insertMessage: InsertMessage): Promise<Message> {
    const [message] = await db
      .insert(messages)
      .values(insertMessage)
      .returning();
    return message;
  }
  
  async getMessagesByChannel(channelId: number): Promise<Message[]> {
    return await db
      .select()
      .from(messages)
      .where(eq(messages.channelId, channelId))
      .orderBy(asc(messages.timestamp));
  }
  
  async getDirectMessages(userId: number, recipientId: number): Promise<Message[]> {
    return await db
      .select()
      .from(messages)
      .where(
        and(
          eq(messages.isDirectMessage, true),
          or(
            and(
              eq(messages.userId, userId),
              eq(messages.recipientId, recipientId)
            ),
            and(
              eq(messages.userId, recipientId),
              eq(messages.recipientId, userId)
            )
          )
        )
      )
      .orderBy(asc(messages.timestamp));
  }
  
  async getConversationPartners(userId: number): Promise<number[]> {
    // Find all direct messages where the user is either sender or recipient
    const messageResults = await db
      .select()
      .from(messages)
      .where(
        and(
          eq(messages.isDirectMessage, true),
          or(
            eq(messages.userId, userId),
            eq(messages.recipientId, userId)
          )
        )
      );
    
    // Extract unique user IDs of conversation partners
    const partnerIds = new Set<number>();
    
    messageResults.forEach(message => {
      if (message.userId === userId && message.recipientId) {
        partnerIds.add(message.recipientId);
      } else if (message.recipientId === userId && message.userId) {
        partnerIds.add(message.userId);
      }
    });
    
    return Array.from(partnerIds);
  }
  
  async markMessageAsRead(messageId: number): Promise<Message | undefined> {
    const [message] = await db
      .update(messages)
      .set({ read: true })
      .where(eq(messages.id, messageId))
      .returning();
    return message;
  }
  
  // Call methods
  async createCall(call: InsertCall): Promise<Call> {
    const [newCall] = await db
      .insert(calls)
      .values(call)
      .returning();
    return newCall;
  }
  
  async getCall(id: number): Promise<Call | undefined> {
    const [call] = await db
      .select()
      .from(calls)
      .where(eq(calls.id, id));
    return call;
  }
  
  async updateCallStatus(id: number, status: string): Promise<Call | undefined> {
    const [call] = await db
      .update(calls)
      .set({ status })
      .where(eq(calls.id, id))
      .returning();
    return call;
  }
  
  async updateCallEnd(id: number): Promise<Call | undefined> {
    const [call] = await db
      .update(calls)
      .set({ 
        status: 'completed',
        endTime: new Date()
      })
      .where(eq(calls.id, id))
      .returning();
    return call;
  }
  
  async getUserCalls(userId: number): Promise<Call[]> {
    return await db
      .select()
      .from(calls)
      .where(
        or(
          eq(calls.callerId, userId),
          eq(calls.receiverId, userId)
        )
      )
      .orderBy(desc(calls.startTime));
  }
  
  // Social media methods - Posts
  async createPost(post: InsertPost): Promise<Post> {
    const [newPost] = await db
      .insert(posts)
      .values(post)
      .returning();
    return newPost;
  }
  
  async getPost(id: number): Promise<Post | undefined> {
    const [post] = await db
      .select()
      .from(posts)
      .where(eq(posts.id, id));
    return post;
  }
  
  async getUserPosts(userId: number): Promise<Post[]> {
    return await db
      .select()
      .from(posts)
      .where(eq(posts.userId, userId))
      .orderBy(desc(posts.timestamp));
  }
  
  async getFeedPosts(): Promise<Post[]> {
    return await db
      .select()
      .from(posts)
      .orderBy(desc(posts.timestamp))
      .limit(20);
  }
  
  async deletePost(id: number): Promise<boolean> {
    // First delete all comments for this post
    await db
      .delete(comments)
      .where(eq(comments.postId, id));
      
    // Then delete the post
    const result = await db
      .delete(posts)
      .where(eq(posts.id, id));
    
    return !!result;
  }
  
  // Social media methods - Comments
  async createComment(comment: InsertComment): Promise<Comment> {
    const [newComment] = await db
      .insert(comments)
      .values(comment)
      .returning();
      
    // Increment comment count on the post
    await db
      .update(posts)
      .set({ 
        comments: sql`${posts.comments} + 1` 
      })
      .where(eq(posts.id, comment.postId));
      
    return newComment;
  }
  
  async getPostComments(postId: number): Promise<Comment[]> {
    return await db
      .select()
      .from(comments)
      .where(eq(comments.postId, postId))
      .orderBy(asc(comments.timestamp));
  }
  
  async deleteComment(id: number): Promise<boolean> {
    // Get the comment to find the post ID
    const [comment] = await db
      .select()
      .from(comments)
      .where(eq(comments.id, id));
      
    if (!comment) return false;
    
    // Delete the comment
    const result = await db
      .delete(comments)
      .where(eq(comments.id, id));
      
    // Decrement comment count on the post
    await db
      .update(posts)
      .set({ 
        comments: sql`${posts.comments} - 1` 
      })
      .where(eq(posts.id, comment.postId));
      
    return !!result;
  }
}

// Memory storage implementation for fallback or testing
export class MemStorage implements IStorage {
  private users: Map<number, User>;
  private channels: Map<number, Channel>;
  private messages: Map<number, Message>;
  private userCurrentId: number;
  private channelCurrentId: number;
  private messageCurrentId: number;
  sessionStore: session.Store;

  constructor() {
    this.users = new Map();
    this.channels = new Map();
    this.messages = new Map();
    this.userCurrentId = 1;
    this.channelCurrentId = 1;
    this.messageCurrentId = 1;
    
    // Create memory session store
    const MemoryStore = require('memorystore')(session);
    this.sessionStore = new MemoryStore({
      checkPeriod: 86400000 // prune expired entries every 24h
    });
    
    // Initialize with some data
    const initialUsers = [
      { 
        username: 'me',
        email: 'me@example.com',
        password: 'password', 
        displayName: 'Me', 
        initials: 'ME',
        color: '#6366F1',
        status: 'online',
        emailVerified: true
      },
      { 
        username: 'sarah',
        email: 'sarah@example.com',
        password: 'password', 
        displayName: 'Sarah Johnson', 
        initials: 'SJ',
        color: '#8B5CF6',
        status: 'online',
        emailVerified: true
      },
      { 
        username: 'mike',
        email: 'mike@example.com',
        password: 'password', 
        displayName: 'Mike Robinson', 
        initials: 'MR',
        color: '#818CF8',
        status: 'offline',
        emailVerified: true
      },
      { 
        username: 'anna',
        email: 'anna@example.com',
        password: 'password', 
        displayName: 'Anna Lee', 
        initials: 'AL',
        color: '#EC4899',
        status: 'away',
        emailVerified: true
      },
      { 
        username: 'james',
        email: 'james@example.com',
        password: 'password', 
        displayName: 'James Taylor', 
        initials: 'JT',
        color: '#60A5FA',
        status: 'online',
        emailVerified: true
      }
    ];
    
    // Create the first user (admin) synchronously since we're in the constructor
    const adminId = this.userCurrentId++;
    const adminUser = { 
      id: adminId,
      username: 'admin',
      email: 'admin@browsy.com',
      password: 'password',
      displayName: 'System Admin',
      initials: 'SA',
      color: '#FF5733',
      status: 'online',
      emailVerified: true,
      profilePicture: null,
      bio: null
    };
    this.users.set(adminId, adminUser);
    
    const initialChannels = [
      { 
        name: 'general', 
        type: 'channel', 
        creatorId: adminId,
        picture: null,
        description: null
      },
      { 
        name: 'random', 
        type: 'channel', 
        creatorId: adminId,
        picture: null,
        description: null
      },
      { 
        name: 'help', 
        type: 'channel', 
        creatorId: adminId,
        picture: null,
        description: null
      }
    ];
    
    // Create users
    initialUsers.forEach(user => {
      this.createUser(user);
    });
    
    // Create channels
    initialChannels.forEach(channel => {
      this.createChannel(channel);
    });
  }

  // User methods
  async getUser(id: number): Promise<User | undefined> {
    return this.users.get(id);
  }

  async getUserByUsername(username: string): Promise<User | undefined> {
    return Array.from(this.users.values()).find(
      (user) => user.username === username,
    );
  }
  
  async getUserByEmail(email: string): Promise<User | undefined> {
    return Array.from(this.users.values()).find(
      (user) => user.email === email,
    );
  }

  async createUser(insertUser: InsertUser): Promise<User> {
    const id = this.userCurrentId++;
    // Ensure that status and emailVerified have default values
    const user: User = { 
      ...insertUser, 
      id, 
      status: insertUser.status || 'offline',
      emailVerified: insertUser.emailVerified !== undefined ? insertUser.emailVerified : false,
      profilePicture: insertUser.profilePicture || null,
      bio: insertUser.bio || null
    };
    this.users.set(id, user);
    return user;
  }
  
  async updateUserStatus(id: number, status: string): Promise<User | undefined> {
    const user = await this.getUser(id);
    if (!user) return undefined;
    
    const updatedUser = { ...user, status };
    this.users.set(id, updatedUser);
    return updatedUser;
  }
  
  async updateUserEmailVerification(id: number, verified: boolean): Promise<User | undefined> {
    const user = await this.getUser(id);
    if (!user) return undefined;
    
    const updatedUser = { ...user, emailVerified: verified };
    this.users.set(id, updatedUser);
    return updatedUser;
  }
  
  async updateUserProfile(id: number, profileData: Partial<User>): Promise<User | undefined> {
    const user = await this.getUser(id);
    if (!user) return undefined;
    
    const updatedUser = { ...user, ...profileData };
    this.users.set(id, updatedUser);
    return updatedUser;
  }
  
  async getAllUsers(): Promise<User[]> {
    return Array.from(this.users.values());
  }

  // Channel methods
  async getChannel(id: number): Promise<Channel | undefined> {
    return this.channels.get(id);
  }
  
  async getChannelByName(name: string): Promise<Channel | undefined> {
    return Array.from(this.channels.values()).find(
      (channel) => channel.name === name,
    );
  }
  
  async createChannel(insertChannel: InsertChannel): Promise<Channel> {
    const id = this.channelCurrentId++;
    const channel: Channel = { 
      ...insertChannel, 
      id, 
      type: insertChannel.type || 'channel',
      unreadCount: 0,
      picture: insertChannel.picture || null,
      description: insertChannel.description || null
    };
    this.channels.set(id, channel);
    return channel;
  }
  
  async updateChannel(id: number, channelData: Partial<Channel>): Promise<Channel | undefined> {
    const channel = await this.getChannel(id);
    if (!channel) return undefined;
    
    const updatedChannel = { ...channel, ...channelData };
    this.channels.set(id, updatedChannel);
    return updatedChannel;
  }

  async getAllChannels(): Promise<Channel[]> {
    return Array.from(this.channels.values());
  }
  
  async getUserChannels(userId: number): Promise<Channel[]> {
    // In memory implementation doesn't track channel members
    // Return all channels for simplicity
    return this.getAllChannels();
  }
  
  async getChannelMembers(channelId: number): Promise<ChannelMember[]> {
    // Memory implementation doesn't track channel members
    return [];
  }
  
  async addChannelMember(member: InsertChannelMember): Promise<ChannelMember> {
    // Simplified implementation
    return {
      id: 1,
      userId: member.userId,
      channelId: member.channelId,
      role: member.role || 'member'
    };
  }
  
  async removeChannelMember(channelId: number, userId: number): Promise<boolean> {
    // Simplified implementation
    return true;
  }
  
  async updateChannelMemberRole(channelId: number, userId: number, role: string): Promise<ChannelMember | undefined> {
    // Simplified implementation
    return {
      id: 1,
      userId,
      channelId,
      role
    };
  }

  // Message methods
  async getMessage(id: number): Promise<Message | undefined> {
    return this.messages.get(id);
  }
  
  async createMessage(insertMessage: InsertMessage): Promise<Message> {
    const id = this.messageCurrentId++;
    const message: Message = { 
      ...insertMessage, 
      id, 
      timestamp: new Date(),
      channelId: insertMessage.channelId || null,
      recipientId: insertMessage.recipientId || null,
      isDirectMessage: insertMessage.isDirectMessage || false,
      attachments: insertMessage.attachments || null,
      read: insertMessage.read || false
    };
    this.messages.set(id, message);
    return message;
  }
  
  async getMessagesByChannel(channelId: number): Promise<Message[]> {
    return Array.from(this.messages.values())
      .filter(message => message.channelId === channelId)
      .sort((a, b) => {
        const aTime = a.timestamp instanceof Date ? a.timestamp.getTime() : new Date(a.timestamp).getTime();
        const bTime = b.timestamp instanceof Date ? b.timestamp.getTime() : new Date(b.timestamp).getTime();
        return aTime - bTime;
      });
  }
  
  async getDirectMessages(userId: number, recipientId: number): Promise<Message[]> {
    return Array.from(this.messages.values())
      .filter(message => 
        message.isDirectMessage && 
        ((message.userId === userId && message.recipientId === recipientId) || 
         (message.userId === recipientId && message.recipientId === userId))
      )
      .sort((a, b) => {
        const aTime = a.timestamp instanceof Date ? a.timestamp.getTime() : new Date(a.timestamp).getTime();
        const bTime = b.timestamp instanceof Date ? b.timestamp.getTime() : new Date(b.timestamp).getTime();
        return aTime - bTime;
      });
  }
  
  async getConversationPartners(userId: number): Promise<number[]> {
    // Get all direct messages where the user is either sender or recipient
    const directMessages = Array.from(this.messages.values())
      .filter(message => 
        message.isDirectMessage && 
        (message.userId === userId || message.recipientId === userId)
      );
    
    // Extract unique user IDs of conversation partners
    const partnerIds = new Set<number>();
    
    directMessages.forEach(message => {
      if (message.userId === userId && message.recipientId) {
        partnerIds.add(message.recipientId);
      } else if (message.recipientId === userId && message.userId) {
        partnerIds.add(message.userId);
      }
    });
    
    return Array.from(partnerIds);
  }
  
  async markMessageAsRead(messageId: number): Promise<Message | undefined> {
    const message = this.messages.get(messageId);
    if (!message) return undefined;
    
    const updatedMessage = { ...message, read: true };
    this.messages.set(messageId, updatedMessage);
    return updatedMessage;
  }
  
  // Call methods
  async createCall(call: InsertCall): Promise<Call> {
    // Simplified implementation
    return {
      id: 1,
      callerId: call.callerId,
      receiverId: call.receiverId || null,
      channelId: call.channelId || null,
      isGroupCall: call.isGroupCall || false,
      isVideoCall: call.isVideoCall || false,
      status: call.status || 'initiated',
      startTime: new Date(),
      endTime: null
    };
  }
  
  async getCall(id: number): Promise<Call | undefined> {
    // Simplified implementation - calls not stored in memory
    return undefined;
  }
  
  async updateCallStatus(id: number, status: string): Promise<Call | undefined> {
    // Simplified implementation - calls not stored in memory
    return {
      id,
      callerId: 1,
      receiverId: 2,
      channelId: null,
      isGroupCall: false,
      isVideoCall: false,
      status,
      startTime: new Date(),
      endTime: null
    };
  }
  
  async updateCallEnd(id: number): Promise<Call | undefined> {
    // Simplified implementation - calls not stored in memory
    return {
      id,
      callerId: 1,
      receiverId: 2,
      channelId: null,
      isGroupCall: false,
      isVideoCall: false,
      status: 'completed',
      startTime: new Date(),
      endTime: new Date()
    };
  }
  
  async getUserCalls(userId: number): Promise<Call[]> {
    // Simplified implementation - calls not stored in memory
    return [];
  }
  
  // Social media methods - Posts
  async createPost(post: InsertPost): Promise<Post> {
    // Simplified implementation
    if (!post.mediaUrl) {
      throw new Error("Media URL is required for posts");
    }
    
    return {
      id: 1,
      userId: post.userId,
      caption: post.caption || null,
      mediaUrl: post.mediaUrl,
      mediaType: post.mediaType,
      isReel: post.isReel || false,
      likes: 0,
      comments: 0,
      timestamp: new Date()
    };
  }
  
  async getPost(id: number): Promise<Post | undefined> {
    // Simplified implementation
    return undefined;
  }
  
  async getUserPosts(userId: number): Promise<Post[]> {
    // Simplified implementation
    return [];
  }
  
  async getFeedPosts(): Promise<Post[]> {
    // Simplified implementation
    return [];
  }
  
  async deletePost(id: number): Promise<boolean> {
    // Simplified implementation
    return true;
  }
  
  // Social media methods - Comments
  async createComment(comment: InsertComment): Promise<Comment> {
    // Simplified implementation
    return {
      id: 1,
      postId: comment.postId,
      userId: comment.userId,
      content: comment.content,
      timestamp: new Date()
    };
  }
  
  async getPostComments(postId: number): Promise<Comment[]> {
    // Simplified implementation
    return [];
  }
  
  async deleteComment(id: number): Promise<boolean> {
    // Simplified implementation
    return true;
  }
}

// Use DatabaseStorage for persistent storage
export const storage = new DatabaseStorage();