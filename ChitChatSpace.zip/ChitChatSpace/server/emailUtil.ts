// Simulated email service for development environments
// In a production environment, this would be replaced with SendGrid or another email provider

export function simulateEmailSent(to: string, subject: string, content: string): Promise<boolean> {
  // Log email details to console for development purposes
  console.log('\n=== SIMULATED EMAIL SENT ===');
  console.log(`To: ${to}`);
  console.log(`Subject: ${subject}`);
  console.log('Content:');
  console.log(content);
  console.log('=============================\n');
  
  // Always return success for simulation
  return Promise.resolve(true);
}

// Function that returns a formatted HTML verification email
export function getVerificationEmailContent(displayName: string, verificationUrl: string): string {
  return `
<!DOCTYPE html>
<html>
<head>
  <style>
    body { font-family: Arial, sans-serif; line-height: 1.6; color: #333; }
    .container { max-width: 600px; margin: 0 auto; padding: 20px; }
    .header { background-color: #4F46E5; padding: 20px; border-radius: 5px 5px 0 0; }
    .header h1 { color: white; margin: 0; }
    .content { padding: 20px; border: 1px solid #ddd; border-top: none; border-radius: 0 0 5px 5px; }
    .button { background-color: #4F46E5; color: white; padding: 12px 20px; text-decoration: none; 
              border-radius: 5px; display: inline-block; margin: 20px 0; font-weight: bold; }
    .footer { font-size: 12px; color: #666; margin-top: 20px; }
  </style>
</head>
<body>
  <div class="container">
    <div class="header">
      <h1>Verify Your Email</h1>
    </div>
    <div class="content">
      <p>Hi ${displayName},</p>
      <p>Thanks for signing up for Browsy! Please verify your email address by clicking the button below:</p>
      <a href="${verificationUrl}" class="button">Verify Email</a>
      <p>If the button doesn't work, copy and paste this link into your browser:</p>
      <p>${verificationUrl}</p>
      <p>This link will expire in 24 hours.</p>
      <p>Thanks,<br>The Browsy Team</p>
    </div>
    <div class="footer">
      <p>If you didn't sign up for a Browsy account, please ignore this email.</p>
    </div>
  </div>
</body>
</html>
  `;
}