import { WebSocketServer, WebSocket } from 'ws';
import { Server } from 'http';
import { storage } from './storage';
import { 
  SocketMessage,
  ChatMessage,
  CallData,
  insertMessageSchema,
  insertCallSchema
} from '@shared/schema';

// Type for tracking clients and their user info
type ConnectedClient = {
  userId: number;
  username: string;
  socket: WebSocket;
};

// Type for tracking typing status
type TypingStatus = { 
  userId: number;
  channelId?: number;
  recipientId?: number;
  isDirectMessage: boolean;
  timestamp: number;
};

// Call tracking
type ActiveCall = {
  callId: number;
  callerId: number;
  receiverId?: number;
  channelId?: number;
  isGroupCall: boolean;
  isVideoCall: boolean;
  startTime: Date;
  participants: Set<number>;
};

export function setupWebSockets(httpServer: Server): WebSocketServer {
  // Tracking all connected clients with their user IDs
  const clients: Map<number, ConnectedClient> = new Map();
  
  // Tracking typing indicators
  const typingUsers: Map<number, TypingStatus> = new Map();
  
  // Active calls
  const activeCalls: Map<number, ActiveCall> = new Map();
  
  // Create WebSocket server
  const wss = new WebSocketServer({ server: httpServer, path: '/ws' });
  
  // Handle new connections
  wss.on('connection', (ws) => {
    // Set initial state for the connection
    let userId: number | null = null;
    let username: string | null = null;
    
    // Handle incoming messages
    ws.on('message', async (data) => {
      try {
        const message: SocketMessage = JSON.parse(data.toString());
        
        switch (message.type) {
          case 'message': {
            if (!userId) {
              ws.send(JSON.stringify({ 
                type: 'error', 
                payload: { message: 'You must be logged in to send messages' } 
              }));
              return;
            }

            const { content, channelId, recipientId, isDirectMessage } = message.payload;
            const insertMessage = insertMessageSchema.parse({
              content,
              userId,
              channelId,
              recipientId,
              isDirectMessage: isDirectMessage || false,
              read: false
            });
            
            const newMessage = await storage.createMessage(insertMessage);
            const user = await storage.getUser(userId);
            
            if (!user) {
              throw new Error('User not found');
            }
            
            // Construct message to broadcast
            const chatMessage: ChatMessage = {
              ...newMessage,
              timestamp: newMessage.timestamp.toString(),
              user: {
                username: user.username,
                displayName: user.displayName,
                initials: user.initials,
                color: user.color,
                profilePicture: user.profilePicture
              }
            };
            
            if (isDirectMessage && recipientId) {
              // Send direct message to recipient and sender only
              sendToUser(recipientId, {
                type: 'message',
                payload: chatMessage
              });
              sendToUser(userId, {
                type: 'message',
                payload: chatMessage
              });
            } else if (channelId) {
              // Broadcast to channel
              broadcastToChannel(channelId, {
                type: 'message',
                payload: chatMessage
              });
            }
            break;
          }
          
          case 'typing': {
            if (!userId) return;
            
            const { channelId, recipientId, isDirectMessage, isTyping } = message.payload;
            
            if (isTyping) {
              // Update typing status
              typingUsers.set(userId, { 
                userId, 
                channelId,
                recipientId,
                isDirectMessage: isDirectMessage || false,
                timestamp: Date.now() 
              });
              
              if (isDirectMessage && recipientId) {
                // Notify recipient of typing
                sendToUser(recipientId, {
                  type: 'typing',
                  payload: { 
                    userId, 
                    isTyping: true,
                    isDirectMessage: true
                  }
                });
              } else if (channelId) {
                // Broadcast typing to channel
                broadcastToChannel(channelId, {
                  type: 'typing',
                  payload: { 
                    userId, 
                    channelId, 
                    isTyping: true,
                    isDirectMessage: false
                  }
                });
              }
            } else {
              // Remove typing status
              typingUsers.delete(userId);
              
              if (isDirectMessage && recipientId) {
                // Notify recipient stopped typing
                sendToUser(recipientId, {
                  type: 'typing',
                  payload: { 
                    userId, 
                    isTyping: false,
                    isDirectMessage: true
                  }
                });
              } else if (channelId) {
                // Broadcast stopped typing to channel
                broadcastToChannel(channelId, {
                  type: 'typing',
                  payload: { 
                    userId, 
                    channelId, 
                    isTyping: false,
                    isDirectMessage: false
                  }
                });
              }
            }
            break;
          }
          
          case 'status': {
            // User identification and status update
            if (message.payload.action === 'identify') {
              userId = message.payload.userId;
              
              if (userId) {
                const user = await storage.getUser(userId);
                if (user) {
                  username = user.username;
                  
                  // Store client information
                  clients.set(userId, { 
                    userId, 
                    username: user.username, 
                    socket: ws 
                  });
                  
                  // Update user status to online in database
                  await storage.updateUserStatus(userId, 'online');
                  
                  // Broadcast user online status to all clients
                  broadcast({
                    type: 'status',
                    payload: { 
                      userId, 
                      status: 'online' 
                    }
                  });
                }
              }
            } else if (message.payload.action === 'update' && userId) {
              // Update status (away, busy, etc)
              const { status } = message.payload;
              await storage.updateUserStatus(userId, status);
              
              broadcast({
                type: 'status',
                payload: { 
                  userId, 
                  status 
                }
              });
            }
            break;
          }
          
          case 'call': {
            if (!userId) {
              ws.send(JSON.stringify({ 
                type: 'error', 
                payload: { message: 'You must be logged in to initiate calls' } 
              }));
              return;
            }

            const { receiverId, channelId, isGroupCall, isVideoCall } = message.payload;
            
            // Create a new call record
            const insertCall = insertCallSchema.parse({
              callerId: userId,
              receiverId,
              channelId,
              isGroupCall: isGroupCall || false,
              isVideoCall: isVideoCall || false,
              status: 'ringing'
            });
            
            const newCall = await storage.createCall(insertCall);
            const caller = await storage.getUser(userId);
            
            if (!caller) {
              throw new Error('Caller not found');
            }
            
            // Create call data to send
            const callData: CallData = {
              id: newCall.id,
              callerId: userId,
              receiverId,
              channelId,
              isGroupCall: isGroupCall || false,
              isVideoCall: isVideoCall || false,
              status: 'ringing',
              caller: {
                username: caller.username,
                displayName: caller.displayName,
                initials: caller.initials,
                profilePicture: caller.profilePicture
              }
            };
            
            // Track active call
            activeCalls.set(newCall.id, {
              callId: newCall.id,
              callerId: userId,
              receiverId,
              channelId,
              isGroupCall: isGroupCall || false,
              isVideoCall: isVideoCall || false,
              startTime: new Date(),
              participants: new Set([userId])
            });
            
            if (isGroupCall && channelId) {
              // Notify everyone in the channel
              broadcastToChannel(channelId, {
                type: 'call',
                payload: callData
              });
            } else if (receiverId) {
              // Send call notification to recipient
              sendToUser(receiverId, {
                type: 'call',
                payload: callData
              });
              
              // Confirm to caller
              sendToUser(userId, {
                type: 'call',
                payload: {
                  ...callData,
                  status: 'outgoing'
                }
              });
            }
            break;
          }
          
          case 'call_response': {
            if (!userId) return;
            
            const { callId, action } = message.payload;
            const call = activeCalls.get(callId);
            
            if (!call) {
              // Call doesn't exist or has ended
              return;
            }
            
            if (action === 'accept') {
              // Add user to participants
              call.participants.add(userId);
              
              // Update call status
              await storage.updateCallStatus(callId, 'ongoing');
              
              // Notify all participants
              for (const participantId of call.participants) {
                sendToUser(participantId, {
                  type: 'call_response',
                  payload: {
                    callId,
                    userId,
                    action: 'accept',
                    participants: Array.from(call.participants)
                  }
                });
              }
            } else if (action === 'reject' || action === 'busy') {
              // If it's the recipient rejecting
              if (call.receiverId === userId) {
                // Update call status
                await storage.updateCallStatus(callId, action === 'reject' ? 'rejected' : 'busy');
                
                // Notify caller
                sendToUser(call.callerId, {
                  type: 'call_response',
                  payload: {
                    callId,
                    userId,
                    action
                  }
                });
                
                // Remove active call
                activeCalls.delete(callId);
              }
            }
            break;
          }
          
          case 'call_end': {
            if (!userId) return;
            
            const { callId } = message.payload;
            const call = activeCalls.get(callId);
            
            if (!call) return;
            
            // Update call status and end time
            await storage.updateCallEnd(callId);
            
            // Notify all participants
            for (const participantId of call.participants) {
              sendToUser(participantId, {
                type: 'call_end',
                payload: {
                  callId,
                  endedBy: userId
                }
              });
            }
            
            // Remove active call
            activeCalls.delete(callId);
            break;
          }
        }
      } catch (error) {
        console.error('WebSocket message error:', error);
        ws.send(JSON.stringify({ 
          type: 'error', 
          payload: { message: 'Invalid message format' } 
        }));
      }
    });
    
    // Handle disconnection
    ws.on('close', async () => {
      if (userId) {
        // Update user status to offline
        await storage.updateUserStatus(userId, 'offline');
        
        // Broadcast status change
        broadcast({
          type: 'status',
          payload: {
            userId,
            status: 'offline'
          }
        });
        
        // Remove from typing users
        typingUsers.delete(userId);
        
        // Handle ongoing calls
        for (const [callId, call] of activeCalls.entries()) {
          if (call.participants.has(userId)) {
            // If it's a one-on-one call or the user is the caller in a group call
            if ((!call.isGroupCall && (call.callerId === userId || call.receiverId === userId)) || 
                (call.isGroupCall && call.callerId === userId)) {
              // End the call for everyone
              for (const participantId of call.participants) {
                if (participantId !== userId) {
                  sendToUser(participantId, {
                    type: 'call_end',
                    payload: {
                      callId,
                      endedBy: userId,
                      reason: 'disconnected'
                    }
                  });
                }
              }
              
              // Update call status and end time
              await storage.updateCallEnd(callId);
              
              // Remove active call
              activeCalls.delete(callId);
            } else if (call.isGroupCall) {
              // Just remove the participant
              call.participants.delete(userId);
              
              // Notify remaining participants
              for (const participantId of call.participants) {
                sendToUser(participantId, {
                  type: 'call_response',
                  payload: {
                    callId,
                    userId,
                    action: 'leave',
                    participants: Array.from(call.participants)
                  }
                });
              }
            }
          }
        }
        
        // Remove from clients map
        clients.delete(userId);
      }
    });
  });
  
  // Clean up expired typing indicators every 5 seconds
  setInterval(() => {
    const now = Date.now();
    Array.from(typingUsers.entries()).forEach(([userId, status]) => {
      // Remove typing status after 3 seconds of inactivity
      if (now - status.timestamp > 3000) {
        typingUsers.delete(userId);
        
        // Notify recipients based on message type
        if (status.isDirectMessage && status.recipientId) {
          sendToUser(status.recipientId, {
            type: 'typing',
            payload: { 
              userId, 
              isTyping: false,
              isDirectMessage: true
            }
          });
        } else if (status.channelId) {
          broadcastToChannel(status.channelId, {
            type: 'typing',
            payload: { 
              userId, 
              channelId: status.channelId, 
              isTyping: false,
              isDirectMessage: false
            }
          });
        }
      }
    });
  }, 5000);
  
  // Utility function to broadcast to all connected clients
  function broadcast(message: SocketMessage) {
    for (const client of clients.values()) {
      if (isSocketOpen(client.socket)) {
        client.socket.send(JSON.stringify(message));
      }
    }
  }
  
  // Utility function to send to specific user
  function sendToUser(userId: number, message: SocketMessage) {
    const client = clients.get(userId);
    if (client && isSocketOpen(client.socket)) {
      client.socket.send(JSON.stringify(message));
    }
  }
  
  // Utility function to broadcast to specific channel
  function broadcastToChannel(channelId: number, message: SocketMessage) {
    // In a real app, we would query for channel members
    // For simplicity, we're broadcasting to all connected clients
    // In the client, they would filter messages by channelId
    broadcast(message);
  }
  
  // Utility function to check if WebSocket is open
  function isSocketOpen(socket: WebSocket): boolean {
    return socket.readyState === WebSocket.OPEN;
  }
  
  return wss;
}