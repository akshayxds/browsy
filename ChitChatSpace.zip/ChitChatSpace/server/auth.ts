import passport from "passport";
import { Strategy as LocalStrategy } from "passport-local";
import { Express } from "express";
import session from "express-session";
import { storage } from "./storage";
import { User } from "@shared/schema";
import crypto from "crypto";
import { simulateEmailSent, getVerificationEmailContent } from "./emailUtil";

declare global {
  namespace Express {
    // Define the User type for passport
    interface User {
      id: number;
      username: string;
      email: string;
      password: string;
      displayName: string;
      initials: string;
      color: string;
      status: string;
      emailVerified: boolean;
      profilePicture?: string;
      bio?: string;
    }
  }
}

// Hash password with crypto
export async function hashPassword(password: string): Promise<string> {
  return new Promise((resolve, reject) => {
    const salt = crypto.randomBytes(16).toString("hex");
    crypto.pbkdf2(password, salt, 10000, 64, "sha512", (err, derivedKey) => {
      if (err) reject(err);
      resolve(`${derivedKey.toString("hex")}.${salt}`);
    });
  });
}

// Compare password with hash
export async function comparePasswords(supplied: string, stored: string): Promise<boolean> {
  return new Promise((resolve, reject) => {
    const [hash, salt] = stored.split(".");
    crypto.pbkdf2(supplied, salt, 10000, 64, "sha512", (err, derivedKey) => {
      if (err) reject(err);
      resolve(derivedKey.toString("hex") === hash);
    });
  });
}

export async function setupAuth(app: Express) {
  const sessionSettings: session.SessionOptions = {
    secret: process.env.SESSION_SECRET || 'chat-app-secret',
    resave: false,
    saveUninitialized: false,
    store: storage.sessionStore,
    cookie: { 
      secure: process.env.NODE_ENV === "production",
      maxAge: 7 * 24 * 60 * 60 * 1000, // 1 week
      sameSite: 'lax' // This fixes cross-domain issues with cookies
    }
  };

  // Add session middleware
  app.use(session(sessionSettings));
  
  // Initialize passport
  app.use(passport.initialize());
  app.use(passport.session());

  // Configure local strategy
  passport.use(
    new LocalStrategy(
      {
        usernameField: "email",
        passwordField: "password"
      },
      async (email, password, done) => {
        try {
          const user = await storage.getUserByEmail(email);
          
          if (!user) {
            return done(null, false, { message: "Invalid email or password" });
          }
          
          // In development, allow 'password' as a master password for all accounts
          if (process.env.NODE_ENV !== "production" && password === "password") {
            return done(null, user);
          }
          
          // Compare password hash
          const isMatch = await comparePasswords(password, user.password);
          
          if (!isMatch) {
            return done(null, false, { message: "Invalid email or password" });
          }
          
          return done(null, user);
        } catch (error) {
          return done(error);
        }
      }
    )
  );

  // Configure passport serialization
  passport.serializeUser((user, done) => {
    done(null, user.id);
  });

  passport.deserializeUser(async (id: number, done) => {
    try {
      const user = await storage.getUser(id);
      done(null, user);
    } catch (error) {
      done(error);
    }
  });

  // Create a verification token map to store email verification tokens
  const verificationTokens = new Map<string, { userId: number, expires: Date }>();

  // Generate verification token for email verification
  function generateVerificationToken(userId: number): string {
    const token = crypto.randomBytes(32).toString('hex');
    // Set expiration for 24 hours from now
    const expires = new Date();
    expires.setHours(expires.getHours() + 24);
    
    verificationTokens.set(token, { userId, expires });
    return token;
  }

  // We're using a simulated email service for development
  // This would be replaced with a real email service like SendGrid in production

  // Send verification email
  async function sendVerificationEmail(email: string, token: string, username: string = 'User') {
    try {
      // Create verification URL
      const verificationUrl = `${process.env.APP_URL || 'http://localhost:3000'}/verify-email?token=${token}`;
      
      // Use our simulated email service instead of actual SMTP
      const emailContent = getVerificationEmailContent(username, verificationUrl);
      const result = await simulateEmailSent(
        email,
        'Verify your Browsy account',
        emailContent
      );
      
      return result;
    } catch (error) {
      console.error('Failed to send verification email:', error);
      return false;
    }
  }

  // Register route
  app.post("/api/register", async (req, res) => {
    try {
      const { username, email, password, confirmPassword } = req.body;
      
      // Check if passwords match
      if (password !== confirmPassword) {
        return res.status(400).json({ error: "Passwords don't match" });
      }
      
      // Check if username already exists
      const existingUsername = await storage.getUserByUsername(username);
      if (existingUsername) {
        return res.status(400).json({ error: "Username already exists" });
      }
      
      // Check if email already exists
      const existingEmail = await storage.getUserByEmail(email);
      if (existingEmail) {
        return res.status(400).json({ error: "Email already registered" });
      }
      
      // Generate user initials from username
      const initials = username
        .substring(0, 2)
        .toUpperCase();
      
      // Generate a random color
      const colors = ["#6366F1", "#8B5CF6", "#EC4899", "#60A5FA", "#818CF8", "#34D399", "#F87171"];
      const color = colors[Math.floor(Math.random() * colors.length)];
      
      // Hash password
      const hashedPassword = await hashPassword(password);
      
      // Create user (not verified by default)
      const user = await storage.createUser({
        username,
        email,
        password: hashedPassword,
        displayName: username,
        initials,
        color,
        status: "online",
        emailVerified: process.env.SKIP_EMAIL_VERIFICATION === 'true', // Only skip verification in development
      });
      
      // Generate verification token and send email
      if (!process.env.SKIP_EMAIL_VERIFICATION) {
        const verificationToken = generateVerificationToken(user.id);
        await sendVerificationEmail(email, verificationToken, username);
      }
      
      // Log the user in
      req.login(user, (err: any) => {
        if (err) {
          return res.status(500).json({ error: "Failed to log in after registration" });
        }
        
        // Don't send password to client
        const { password, ...userWithoutPassword } = user;
        res.status(201).json({
          ...userWithoutPassword,
          emailVerificationSent: !process.env.SKIP_EMAIL_VERIFICATION
        });
      });
    } catch (error) {
      console.error("Registration error:", error);
      res.status(500).json({ error: "Registration failed" });
    }
  });
  
  // Email verification route
  app.get("/api/verify-email", async (req, res) => {
    try {
      const { token } = req.query;
      
      if (!token || typeof token !== 'string') {
        return res.status(400).json({ error: "Invalid verification token" });
      }
      
      const verification = verificationTokens.get(token);
      
      // Check if token exists and is not expired
      if (!verification) {
        return res.status(400).json({ error: "Invalid or expired verification token" });
      }
      
      if (verification.expires < new Date()) {
        verificationTokens.delete(token);
        return res.status(400).json({ error: "Verification token has expired" });
      }
      
      // Update user as verified
      const user = await storage.updateUserEmailVerification(verification.userId, true);
      
      if (!user) {
        return res.status(404).json({ error: "User not found" });
      }
      
      // Remove token
      verificationTokens.delete(token);
      
      // If user is logged in, update their session
      if (req.isAuthenticated() && req.user && req.user.id === verification.userId) {
        req.user.emailVerified = true;
      }
      
      return res.status(200).json({ success: true, message: "Email verified successfully" });
    } catch (error) {
      console.error("Email verification error:", error);
      return res.status(500).json({ error: "Failed to verify email" });
    }
  });
  
  // Resend verification email
  app.post("/api/resend-verification", async (req, res) => {
    try {
      if (!req.isAuthenticated() || !req.user) {
        return res.status(401).json({ error: "You must be logged in to request email verification" });
      }
      
      // Check if already verified
      if (req.user.emailVerified) {
        return res.status(400).json({ error: "Your email is already verified" });
      }
      
      // Generate new token and send email
      const verificationToken = generateVerificationToken(req.user.id);
      const emailSent = await sendVerificationEmail(req.user.email, verificationToken);
      
      if (!emailSent) {
        return res.status(500).json({ error: "Failed to send verification email" });
      }
      
      return res.status(200).json({ success: true, message: "Verification email sent" });
    } catch (error) {
      console.error("Resend verification error:", error);
      return res.status(500).json({ error: "Failed to resend verification email" });
    }
  });

  // Login route
  app.post("/api/login", (req, res, next) => {
    passport.authenticate("local", (err: any, user: Express.User | false, info: { message: string } | undefined) => {
      if (err) {
        return next(err);
      }
      
      if (!user) {
        return res.status(401).json({ error: info?.message || "Invalid credentials" });
      }
      
      req.login(user, async (err: any) => {
        if (err) {
          return next(err);
        }
        
        // Update user status to online
        await storage.updateUserStatus(user.id, "online");
        
        // Don't send password to client
        const { password, ...userWithoutPassword } = user;
        return res.json(userWithoutPassword);
      });
    })(req, res, next);
  });

  // Logout route
  app.post("/api/logout", async (req, res) => {
    // Update user status to offline if logged in
    if (req.user) {
      await storage.updateUserStatus(req.user.id, "offline");
    }
    
    req.logout((err: any) => {
      if (err) {
        return res.status(500).json({ error: "Failed to log out" });
      }
      res.json({ message: "Logged out successfully" });
    });
  });

  // Get current user
  app.get("/api/user", (req, res) => {
    if (!req.isAuthenticated() || !req.user) {
      return res.status(401).json({ error: "Not authenticated" });
    }
    
    // Don't send password to client
    const { password, ...userWithoutPassword } = req.user;
    res.json(userWithoutPassword);
  });
}