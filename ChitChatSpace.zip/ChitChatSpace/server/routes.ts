import type { Express, Request, Response, NextFunction } from "express";
import { createServer, type Server } from "http";
import { WebSocketServer, WebSocket } from "ws";
import { storage } from "./storage";
import { 
  insertUserSchema, 
  insertChannelSchema, 
  insertMessageSchema, 
  type SocketMessage, 
  type ChatMessage,
  type CallData
} from "@shared/schema";
import { ZodError } from "zod";
import { setupAuth } from "./auth";
import { hashPassword, comparePasswords } from "./auth";

// Middleware to check if user is authenticated
function isAuthenticated(req: Request, res: Response, next: NextFunction) {
  if (req.isAuthenticated()) {
    return next();
  }
  res.status(401).json({ error: "Not authenticated" });
}

// Track typing status
type TypingStatus = { 
  userId: number;
  channelId?: number;
  recipientId?: number;
  isDirectMessage?: boolean;
  timestamp: number;
};

export async function registerRoutes(app: Express): Promise<Server> {
  const httpServer = createServer(app);
  const clients = new Map<WebSocket, { userId: number }>();
  const typingUsers = new Map<number, TypingStatus>();

  // Setup authentication
  await setupAuth(app);
  
  // Create WebSocket server
  const wss = new WebSocketServer({ server: httpServer, path: '/ws' });

  // Initialize API routes
  
  // Get all channels
  app.get('/api/channels', async (req, res) => {
    try {
      const channels = await storage.getAllChannels();
      res.json(channels);
    } catch (error) {
      res.status(500).json({ error: 'Failed to fetch channels' });
    }
  });
  
  // Social media endpoints - Posts
  
  // Get posts for the feed
  app.get('/api/posts', isAuthenticated, async (req, res) => {
    try {
      const posts = await storage.getFeedPosts();
      
      // Enrich with user data
      const enrichedPosts = await Promise.all(posts.map(async (post) => {
        const user = await storage.getUser(post.userId);
        if (!user) {
          throw new Error(`User not found for post ${post.id}`);
        }
        
        return {
          ...post,
          timestamp: post.timestamp.toString(),
          user: {
            username: user.username,
            displayName: user.displayName,
            profilePicture: user.profilePicture
          }
        };
      }));
      
      res.json(enrichedPosts);
    } catch (error) {
      console.error('Error fetching posts:', error);
      res.status(500).json({ error: 'Failed to fetch posts' });
    }
  });
  
  // Get posts by user
  app.get('/api/users/:id/posts', isAuthenticated, async (req, res) => {
    try {
      const userId = parseInt(req.params.id);
      const posts = await storage.getUserPosts(userId);
      
      // Get user data
      const user = await storage.getUser(userId);
      if (!user) {
        return res.status(404).json({ error: 'User not found' });
      }
      
      // Format posts with user data
      const enrichedPosts = posts.map(post => ({
        ...post,
        timestamp: post.timestamp.toString(),
        user: {
          username: user.username,
          displayName: user.displayName,
          profilePicture: user.profilePicture
        }
      }));
      
      res.json(enrichedPosts);
    } catch (error) {
      console.error('Error fetching user posts:', error);
      res.status(500).json({ error: 'Failed to fetch user posts' });
    }
  });
  
  // Create a new post
  app.post('/api/posts', isAuthenticated, async (req, res) => {
    try {
      const { caption, mediaUrl, mediaType, isReel = false } = req.body;
      
      if (!mediaUrl) {
        return res.status(400).json({ error: 'Media URL is required' });
      }
      
      if (!mediaType) {
        return res.status(400).json({ error: 'Media type is required' });
      }
      
      const userId = req.user!.id;
      
      // Create the post
      const newPost = await storage.createPost({
        userId,
        caption,
        mediaUrl,
        mediaType,
        isReel,
        timestamp: new Date(),
        likes: 0,
        comments: 0
      });
      
      // Get user data
      const user = await storage.getUser(userId);
      if (!user) {
        return res.status(404).json({ error: 'User not found' });
      }
      
      // Format response
      const enrichedPost = {
        ...newPost,
        timestamp: newPost.timestamp.toString(),
        user: {
          username: user.username,
          displayName: user.displayName,
          profilePicture: user.profilePicture
        }
      };
      
      res.status(201).json(enrichedPost);
    } catch (error) {
      console.error('Error creating post:', error);
      res.status(500).json({ error: 'Failed to create post' });
    }
  });
  
  // Delete a post
  app.delete('/api/posts/:id', isAuthenticated, async (req, res) => {
    try {
      const postId = parseInt(req.params.id);
      const userId = req.user!.id;
      
      // Check if post exists and belongs to the user
      const post = await storage.getPost(postId);
      if (!post) {
        return res.status(404).json({ error: 'Post not found' });
      }
      
      if (post.userId !== userId) {
        return res.status(403).json({ error: 'You can only delete your own posts' });
      }
      
      // Delete the post
      const result = await storage.deletePost(postId);
      
      if (result) {
        res.json({ success: true });
      } else {
        res.status(500).json({ error: 'Failed to delete post' });
      }
    } catch (error) {
      console.error('Error deleting post:', error);
      res.status(500).json({ error: 'Failed to delete post' });
    }
  });
  
  // Comments endpoints
  
  // Get comments for a post
  app.get('/api/posts/:id/comments', isAuthenticated, async (req, res) => {
    try {
      const postId = parseInt(req.params.id);
      
      // Check if post exists
      const post = await storage.getPost(postId);
      if (!post) {
        return res.status(404).json({ error: 'Post not found' });
      }
      
      const comments = await storage.getPostComments(postId);
      
      // Enrich with user data
      const enrichedComments = await Promise.all(comments.map(async (comment) => {
        const user = await storage.getUser(comment.userId);
        if (!user) {
          throw new Error(`User not found for comment ${comment.id}`);
        }
        
        return {
          ...comment,
          timestamp: comment.timestamp.toString(),
          user: {
            username: user.username,
            displayName: user.displayName,
            profilePicture: user.profilePicture
          }
        };
      }));
      
      res.json(enrichedComments);
    } catch (error) {
      console.error('Error fetching comments:', error);
      res.status(500).json({ error: 'Failed to fetch comments' });
    }
  });
  
  // Add a comment to a post
  app.post('/api/posts/:id/comments', isAuthenticated, async (req, res) => {
    try {
      const postId = parseInt(req.params.id);
      const { content } = req.body;
      const userId = req.user!.id;
      
      if (!content) {
        return res.status(400).json({ error: 'Comment content is required' });
      }
      
      // Check if post exists
      const post = await storage.getPost(postId);
      if (!post) {
        return res.status(404).json({ error: 'Post not found' });
      }
      
      // Create the comment
      const newComment = await storage.createComment({
        postId,
        userId,
        content,
        timestamp: new Date()
      });
      
      // Get user data
      const user = await storage.getUser(userId);
      if (!user) {
        return res.status(404).json({ error: 'User not found' });
      }
      
      // Format response
      const enrichedComment = {
        ...newComment,
        timestamp: newComment.timestamp.toString(),
        user: {
          username: user.username,
          displayName: user.displayName,
          profilePicture: user.profilePicture
        }
      };
      
      res.status(201).json(enrichedComment);
    } catch (error) {
      console.error('Error creating comment:', error);
      res.status(500).json({ error: 'Failed to create comment' });
    }
  });
  
  // Delete a comment
  app.delete('/api/comments/:id', isAuthenticated, async (req, res) => {
    try {
      const commentId = parseInt(req.params.id);
      const userId = req.user!.id;
      
      // Verify the comment exists and belongs to the user
      // TODO: Implement comment verification
      
      // Delete the comment
      const result = await storage.deleteComment(commentId);
      
      if (result) {
        res.json({ success: true });
      } else {
        res.status(500).json({ error: 'Failed to delete comment' });
      }
    } catch (error) {
      console.error('Error deleting comment:', error);
      res.status(500).json({ error: 'Failed to delete comment' });
    }
  });

  // Get channel by ID
  app.get('/api/channels/:id', async (req, res) => {
    try {
      const channelId = parseInt(req.params.id);
      const channel = await storage.getChannel(channelId);
      
      if (!channel) {
        return res.status(404).json({ error: 'Channel not found' });
      }
      
      res.json(channel);
    } catch (error) {
      res.status(500).json({ error: 'Failed to fetch channel' });
    }
  });

  // Create a new channel
  app.post('/api/channels', async (req, res) => {
    try {
      const channelData = insertChannelSchema.parse(req.body);
      const newChannel = await storage.createChannel(channelData);
      res.status(201).json(newChannel);
    } catch (error) {
      if (error instanceof ZodError) {
        return res.status(400).json({ error: error.errors });
      }
      res.status(500).json({ error: 'Failed to create channel' });
    }
  });

  // Get all users
  app.get('/api/users', async (req, res) => {
    try {
      const users = await storage.getAllUsers();
      // Don't send passwords to the client
      const safeUsers = users.map(u => {
        const { password, ...userWithoutPassword } = u;
        return userWithoutPassword;
      });
      res.json(safeUsers);
    } catch (error) {
      res.status(500).json({ error: 'Failed to fetch users' });
    }
  });
  
  // Get user by ID
  app.get('/api/users/:id', isAuthenticated, async (req, res) => {
    try {
      const userId = parseInt(req.params.id);
      const user = await storage.getUser(userId);
      
      if (!user) {
        return res.status(404).json({ error: 'User not found' });
      }
      
      // Don't send password
      const { password, ...userWithoutPassword } = user;
      
      res.json(userWithoutPassword);
    } catch (error) {
      console.error('Error fetching user:', error);
      res.status(500).json({ error: 'Failed to fetch user' });
    }
  });
  
  // Update user profile with direct authentication
  app.put('/api/users/:id', async (req, res) => {
    try {
      const userId = parseInt(req.params.id);
      
      // Check auth header for direct API call authentication
      const { username, email, displayName, bio, profilePicture, currentPassword, newPassword } = req.body;
      
      // Direct API authentication - verify user with credentials
      if (!currentPassword) {
        return res.status(401).json({ error: 'Authentication required' });
      }
      
      // Verify user exists
      const user = await storage.getUser(userId);
      if (!user) {
        return res.status(404).json({ error: 'User not found' });
      }
      
      // Verify the current password
      const passwordMatches = await comparePasswords(currentPassword, user.password);
      if (!passwordMatches) {
        return res.status(401).json({ error: 'Current password is incorrect' });
      }
      
      // After this point, user is authenticated
      console.log('User authenticated for profile update:', userId);
      
      // Prepare update data
      const updateData: any = {};
      
      // Handle password update if new password is provided
      if (newPassword) {
        const hashedNewPassword = await hashPassword(newPassword);
        // Update password in user data
        updateData.password = hashedNewPassword;
        console.log('Updating user password');
      }
      
      if (username) updateData.username = username;
      if (email) updateData.email = email;
      if (displayName) updateData.displayName = displayName;
      if (bio !== undefined) updateData.bio = bio;
      
      // Handle profile picture - could be a URL or a Base64 encoded string
      if (profilePicture !== undefined) {
        // If it's a data URL (from file upload)
        if (profilePicture && profilePicture.startsWith('data:image/')) {
          // Store the Base64 data directly
          console.log('Updating profile picture with Base64 data');
        }
        updateData.profilePicture = profilePicture;
      }
      
      // Update the user's profile
      const updatedUser = await storage.updateUserProfile(userId, updateData);
      
      if (!updatedUser) {
        return res.status(404).json({ error: 'User not found' });
      }
      
      // Don't send password back
      const { password, ...userWithoutPassword } = updatedUser;
      
      // If the user is logged in, update their session
      if (req.user && req.user.id === userId) {
        // Copy the updated properties to the session user
        Object.assign(req.user, userWithoutPassword);
      }
      
      res.json(userWithoutPassword);
    } catch (error) {
      console.error('Error updating user:', error);
      res.status(500).json({ error: 'Failed to update user profile' });
    }
  });

  // Get messages for a channel
  app.get('/api/channels/:id/messages', async (req, res) => {
    try {
      const channelId = parseInt(req.params.id);
      const messages = await storage.getMessagesByChannel(channelId);
      
      // Enrich messages with user data
      const enrichedMessages: ChatMessage[] = await Promise.all(
        messages.map(async (message) => {
          const user = await storage.getUser(message.userId);
          if (!user) throw new Error(`User not found for message ${message.id}`);
          
          const { password, ...userWithoutPassword } = user;
          
          return {
            ...message,
            timestamp: message.timestamp.toString(),
            user: {
              username: user.username,
              displayName: user.displayName,
              initials: user.initials,
              color: user.color
            }
          };
        })
      );
      
      res.json(enrichedMessages);
    } catch (error) {
      res.status(500).json({ error: 'Failed to fetch messages' });
    }
  });

  // NOTE: Authentication routes (/api/register, /api/login, /api/logout, /api/user) 
  // are handled in server/auth.ts using Passport.js and session-based authentication.
  
  // Get conversation partners (users the authenticated user has exchanged messages with)
  app.get('/api/conversation-partners', isAuthenticated, async (req, res) => {
    try {
      if (!req.user) {
        return res.status(401).json({ error: "Not authenticated" });
      }
      
      const userId = req.user.id;
      const partnerIds = await storage.getConversationPartners(userId);
      
      if (partnerIds.length === 0) {
        return res.json([]);
      }
      
      // Get full user objects for each partner ID
      const partners = await Promise.all(
        partnerIds.map(async (partnerId) => {
          const user = await storage.getUser(partnerId);
          if (!user) return null;
          
          // Remove sensitive data
          const { password, ...userWithoutPassword } = user;
          return userWithoutPassword;
        })
      );
      
      // Filter out any null values (users that might have been deleted)
      const validPartners = partners.filter(partner => partner !== null);
      
      res.json(validPartners);
    } catch (error) {
      console.error('Error fetching conversation partners:', error);
      res.status(500).json({ error: "Failed to fetch conversation partners" });
    }
  });
  
  // Direct message endpoints
  app.get('/api/messages/direct', isAuthenticated, async (req, res) => {
    try {
      const userId = parseInt(req.query.userId as string);
      const recipientId = parseInt(req.query.recipientId as string);
      
      if (isNaN(userId) || isNaN(recipientId)) {
        return res.status(400).json({ error: "Invalid user IDs" });
      }
      
      const messages = await storage.getDirectMessages(userId, recipientId);
      
      // Add additional user information to messages
      const messagesWithUserInfo = await Promise.all(messages.map(async (message) => {
        const user = await storage.getUser(message.userId);
        if (!user) return message;
        
        return {
          ...message,
          timestamp: message.timestamp.toString(),
          user: {
            username: user.username,
            displayName: user.displayName,
            initials: user.initials,
            color: user.color,
            profilePicture: user.profilePicture
          }
        };
      }));
      
      res.json(messagesWithUserInfo);
    } catch (error) {
      console.error('Error fetching direct messages:', error);
      res.status(500).json({ error: "Failed to fetch direct messages" });
    }
  });
  
  // Create a new message (both channel and direct messages)
  app.post('/api/messages', isAuthenticated, async (req, res) => {
    try {
      const { content, channelId, recipientId, isDirectMessage = false } = req.body;
      
      if (!content) {
        return res.status(400).json({ error: "Message content is required" });
      }
      
      if (isDirectMessage && !recipientId) {
        return res.status(400).json({ error: "Recipient ID is required for direct messages" });
      }
      
      if (!isDirectMessage && !channelId) {
        return res.status(400).json({ error: "Channel ID is required for channel messages" });
      }
      
      const userId = req.user!.id;
      
      // Create the message
      const newMessage = await storage.createMessage({
        content,
        userId,
        channelId: isDirectMessage ? null : channelId,
        recipientId: isDirectMessage ? recipientId : null,
        isDirectMessage,
        timestamp: new Date(),
        read: false
      });
      
      // Get user info for the response
      const user = await storage.getUser(userId);
      if (!user) {
        return res.status(404).json({ error: "User not found" });
      }
      
      // Format the response
      const messageResponse = {
        ...newMessage,
        timestamp: newMessage.timestamp.toString(),
        user: {
          username: user.username,
          displayName: user.displayName,
          initials: user.initials,
          color: user.color,
          profilePicture: user.profilePicture
        }
      };
      
      // If it's a direct message, send it via WebSocket
      if (isDirectMessage && recipientId) {
        // Find recipient's WebSocket connection
        let recipientSocket: WebSocket | null = null;
        
        for (const [ws, clientInfo] of clients.entries()) {
          if (clientInfo.userId === recipientId) {
            recipientSocket = ws;
            break;
          }
        }
        
        // Send the message if recipient is connected
        if (recipientSocket && recipientSocket.readyState === WebSocket.OPEN) {
          recipientSocket.send(JSON.stringify({
            type: 'message',
            payload: {
              ...messageResponse,
              isDirectMessage: true
            }
          }));
        }
      }
      
      res.status(201).json(messageResponse);
    } catch (error) {
      console.error('Error creating message:', error);
      res.status(500).json({ error: "Failed to create message" });
    }
  });

  // WebSocket connection handler
  wss.on('connection', (ws) => {
    // Set initial state for the connection
    let userId: number | null = null;
    
    // Handle messages from client
    ws.on('message', async (data) => {
      try {
        const message: SocketMessage = JSON.parse(data.toString());
        
        switch (message.type) {
          case 'message': {
            // Validate and save message to storage
            if (!userId) {
              ws.send(JSON.stringify({ 
                type: 'error', 
                payload: { message: 'You must be logged in to send messages' } 
              }));
              return;
            }

            const { content, channelId, recipientId, isDirectMessage = false } = message.payload;
            
            if (isDirectMessage && !recipientId) {
              ws.send(JSON.stringify({ 
                type: 'error', 
                payload: { message: 'Recipient ID is required for direct messages' } 
              }));
              return;
            }
            
            if (!isDirectMessage && !channelId) {
              ws.send(JSON.stringify({ 
                type: 'error', 
                payload: { message: 'Channel ID is required for channel messages' } 
              }));
              return;
            }
            
            // Create the message
            const newMessage = await storage.createMessage({
              content,
              userId,
              channelId: isDirectMessage ? null : channelId,
              recipientId: isDirectMessage ? recipientId : null,
              isDirectMessage,
              read: false
            });
            
            const user = await storage.getUser(userId);
            
            if (!user) {
              throw new Error('User not found');
            }
            
            // Format the message with user data
            const chatMessage = {
              ...newMessage,
              timestamp: newMessage.timestamp.toString(),
              user: {
                username: user.username,
                displayName: user.displayName,
                initials: user.initials,
                color: user.color,
                profilePicture: user.profilePicture
              }
            };
            
            if (isDirectMessage && recipientId) {
              // For direct messages, only send to the recipient
              for (const [clientWs, clientInfo] of clients.entries()) {
                if (clientInfo.userId === recipientId && clientWs.readyState === WebSocket.OPEN) {
                  clientWs.send(JSON.stringify({
                    type: 'message',
                    payload: chatMessage
                  }));
                  break;
                }
              }
              
              // Also send back to the sender
              ws.send(JSON.stringify({
                type: 'message',
                payload: chatMessage
              }));
            } else if (channelId) {
              // For channel messages, broadcast to all clients
              broadcastToChannel(channelId, {
                type: 'message',
                payload: chatMessage
              });
            }
            break;
          }
          
          case 'typing': {
            if (!userId) return;
            
            const { channelId, recipientId, isDirectMessage = false } = message.payload;
            
            // Update typing status
            typingUsers.set(userId, { 
              userId, 
              channelId: isDirectMessage ? undefined : channelId,
              recipientId: isDirectMessage ? recipientId : undefined,
              isDirectMessage,
              timestamp: Date.now() 
            });
            
            if (isDirectMessage && recipientId) {
              // For direct messages, only send typing indicator to the recipient
              for (const [clientWs, clientInfo] of clients.entries()) {
                if (clientInfo.userId === recipientId && clientWs.readyState === WebSocket.OPEN) {
                  clientWs.send(JSON.stringify({
                    type: 'typing',
                    payload: { 
                      userId, 
                      recipientId, 
                      isDirectMessage: true,
                      isTyping: true 
                    }
                  }));
                  break;
                }
              }
            } else if (channelId) {
              // For channel messages, broadcast to all clients in the channel
              broadcastToChannel(channelId, {
                type: 'typing',
                payload: { 
                  userId, 
                  channelId, 
                  isDirectMessage: false,
                  isTyping: true 
                }
              });
            }
            break;
          }
          
          case 'status': {
            // User identification and status update
            if (message.payload.action === 'identify') {
              userId = message.payload.userId;
              
              if (userId !== null) {
                clients.set(ws, { userId });
                
                // Update user status to online
                await storage.updateUserStatus(userId, 'online');
                
                // Broadcast user status to all clients
                broadcast({
                  type: 'status',
                  payload: { 
                    userId, 
                    status: 'online' 
                  }
                });
              }
            } else if (message.payload.action === 'update' && userId) {
              const { status } = message.payload;
              
              // Update user status in the database
              await storage.updateUserStatus(userId, status);
              
              // Broadcast status update to all clients
              broadcast({
                type: 'status',
                payload: { 
                  userId, 
                  status 
                }
              });
            }
            break;
          }
          
          case 'call': {
            if (!userId) {
              ws.send(JSON.stringify({ 
                type: 'error', 
                payload: { message: 'You must be logged in to initiate calls' } 
              }));
              return;
            }
            
            const { receiverId, isVideo = false } = message.payload;
            
            if (!receiverId) {
              ws.send(JSON.stringify({ 
                type: 'error', 
                payload: { message: 'Recipient ID is required for calls' } 
              }));
              return;
            }
            
            // Create a call record
            const newCall = await storage.createCall({
              callerId: userId,
              receiverId,
              isGroupCall: false,
              isVideoCall: isVideo,
              status: 'ringing',
              startTime: new Date(),
              endTime: null
            });
            
            // Get user info
            const caller = await storage.getUser(userId);
            if (!caller) {
              throw new Error('Caller not found');
            }
            
            // Add to active calls
            activeCalls.set(newCall.id, {
              callerId: userId,
              receiverId,
              startTime: new Date(),
              isVideo
            });
            
            // Format call data
            const callData: CallData = {
              id: newCall.id,
              callerId: userId,
              receiverId,
              isGroupCall: false,
              isVideoCall: isVideo,
              status: 'ringing',
              caller: {
                username: caller.username,
                displayName: caller.displayName,
                initials: caller.initials,
                profilePicture: caller.profilePicture
              }
            };
            
            // Send call notification to recipient
            for (const [clientWs, clientInfo] of clients.entries()) {
              if (clientInfo.userId === receiverId && clientWs.readyState === WebSocket.OPEN) {
                clientWs.send(JSON.stringify({
                  type: 'call',
                  payload: callData
                }));
                break;
              }
            }
            
            // Send confirmation to caller
            ws.send(JSON.stringify({
              type: 'call_initiated',
              payload: {
                callId: newCall.id,
                receiverId,
                isVideo
              }
            }));
            
            break;
          }
          
          case 'call_response': {
            if (!userId) {
              ws.send(JSON.stringify({ 
                type: 'error', 
                payload: { message: 'You must be logged in to respond to calls' } 
              }));
              return;
            }
            
            const { callId, status } = message.payload;
            
            if (!callId) {
              ws.send(JSON.stringify({ 
                type: 'error', 
                payload: { message: 'Call ID is required' } 
              }));
              return;
            }
            
            if (!status || !['accepted', 'declined', 'ended'].includes(status)) {
              ws.send(JSON.stringify({ 
                type: 'error', 
                payload: { message: 'Valid status required (accepted, declined, ended)' } 
              }));
              return;
            }
            
            // Get the call
            const call = await storage.getCall(callId);
            if (!call) {
              ws.send(JSON.stringify({ 
                type: 'error', 
                payload: { message: 'Call not found' } 
              }));
              return;
            }
            
            // Make sure the user is part of this call
            if (call.callerId !== userId && call.receiverId !== userId) {
              ws.send(JSON.stringify({ 
                type: 'error', 
                payload: { message: 'You are not authorized to modify this call' } 
              }));
              return;
            }
            
            // Update call status
            let updatedCall;
            if (status === 'ended') {
              updatedCall = await storage.updateCallEnd(callId);
              
              // Remove from active calls
              activeCalls.delete(callId);
            } else {
              updatedCall = await storage.updateCallStatus(callId, status);
            }
            
            // Send response to the other party
            const otherUserId = userId === call.callerId ? call.receiverId : call.callerId;
            
            for (const [clientWs, clientInfo] of clients.entries()) {
              if (clientInfo.userId === otherUserId && clientWs.readyState === WebSocket.OPEN) {
                clientWs.send(JSON.stringify({
                  type: 'call_response',
                  payload: {
                    callId,
                    status,
                    userId
                  }
                }));
                break;
              }
            }
            
            break;
          }
        }
      } catch (error) {
        console.error('WebSocket message error:', error);
        ws.send(JSON.stringify({ 
          type: 'error', 
          payload: { message: 'Invalid message format' } 
        }));
      }
    });
    
    // Handle disconnection
    ws.on('close', async () => {
      if (userId) {
        const clientInfo = clients.get(ws);
        if (clientInfo) {
          // Update user status to offline
          await storage.updateUserStatus(clientInfo.userId, 'offline');
          
          // Broadcast status change
          broadcast({
            type: 'status',
            payload: {
              userId: clientInfo.userId,
              status: 'offline'
            }
          });
          
          // Remove from typing users if necessary
          typingUsers.delete(clientInfo.userId);
          
          // Remove from clients map
          clients.delete(ws);
        }
      }
    });
  });
  
  // Utility function to broadcast to all connected clients
  function broadcast(message: SocketMessage) {
    wss.clients.forEach(client => {
      if (client.readyState === WebSocket.OPEN) {
        client.send(JSON.stringify(message));
      }
    });
  }
  
  // Utility function to broadcast to specific channel
  function broadcastToChannel(channelId: number, message: SocketMessage) {
    wss.clients.forEach(client => {
      if (client.readyState === WebSocket.OPEN) {
        client.send(JSON.stringify(message));
      }
    });
  }

  // Handle calls between users
  // Active calls
  const activeCalls = new Map<number, { 
    callerId: number;
    receiverId: number;
    startTime: Date;
    isVideo: boolean;
  }>();
  
  // Calls endpoints
  app.post('/api/calls', isAuthenticated, async (req, res) => {
    try {
      const { receiverId, isVideo = false } = req.body;
      const callerId = req.user!.id;
      
      if (!receiverId) {
        return res.status(400).json({ error: "Recipient ID is required" });
      }
      
      // Get the receiver user
      const receiver = await storage.getUser(receiverId);
      if (!receiver) {
        return res.status(404).json({ error: "Recipient not found" });
      }
      
      // Create a call record
      const newCall = await storage.createCall({
        callerId,
        receiverId,
        isGroupCall: false,
        isVideoCall: isVideo,
        startTime: new Date(),
        status: 'ringing',
        endTime: null
      });
      
      // Get caller info
      const caller = await storage.getUser(callerId);
      if (!caller) {
        return res.status(404).json({ error: "Caller not found" });
      }
      
      // Keep track of active call
      activeCalls.set(newCall.id, {
        callerId,
        receiverId,
        startTime: new Date(),
        isVideo
      });
      
      // Send call notification to the recipient via WebSocket
      for (const [ws, clientInfo] of clients.entries()) {
        if (clientInfo.userId === receiverId && ws.readyState === WebSocket.OPEN) {
          const callData: CallData = {
            id: newCall.id,
            callerId,
            receiverId,
            isGroupCall: false,
            isVideoCall: isVideo,
            status: 'ringing',
            caller: {
              username: caller.username,
              displayName: caller.displayName,
              initials: caller.initials,
              profilePicture: caller.profilePicture
            }
          };
          
          ws.send(JSON.stringify({
            type: 'call',
            payload: callData
          }));
          break;
        }
      }
      
      res.status(201).json(newCall);
    } catch (error) {
      console.error('Error creating call:', error);
      res.status(500).json({ error: "Failed to create call" });
    }
  });
  
  // Update call status
  app.put('/api/calls/:id', isAuthenticated, async (req, res) => {
    try {
      const callId = parseInt(req.params.id);
      const { status } = req.body;
      
      if (!status || !['accepted', 'declined', 'ended'].includes(status)) {
        return res.status(400).json({ error: "Valid status required (accepted, declined, ended)" });
      }
      
      // Get the call
      const call = await storage.getCall(callId);
      if (!call) {
        return res.status(404).json({ error: "Call not found" });
      }
      
      let updatedCall;
      
      if (status === 'ended') {
        updatedCall = await storage.updateCallEnd(callId);
        
        // Remove from active calls
        activeCalls.delete(callId);
      } else {
        updatedCall = await storage.updateCallStatus(callId, status);
      }
      
      // Notify the other party
      const otherUserId = req.user!.id === call.callerId ? call.receiverId : call.callerId;
      
      for (const [ws, clientInfo] of clients.entries()) {
        if (clientInfo.userId === otherUserId && ws.readyState === WebSocket.OPEN) {
          ws.send(JSON.stringify({
            type: 'call_response',
            payload: {
              callId,
              status,
              userId: req.user!.id
            }
          }));
          break;
        }
      }
      
      res.json(updatedCall);
    } catch (error) {
      console.error('Error updating call:', error);
      res.status(500).json({ error: "Failed to update call" });
    }
  });

  // Clean up expired typing indicators every 5 seconds
  setInterval(() => {
    const now = Date.now();
    // Use Array.from to convert the Map entries to an array
    Array.from(typingUsers.entries()).forEach(([userId, status]) => {
      // Remove typing status after 3 seconds of inactivity
      if (now - status.timestamp > 3000) {
        typingUsers.delete(userId);
        
        if (status.isDirectMessage && status.recipientId) {
          // For direct messages, notify the recipient that typing has stopped
          for (const [ws, clientInfo] of clients.entries()) {
            if (clientInfo.userId === status.recipientId && ws.readyState === WebSocket.OPEN) {
              ws.send(JSON.stringify({
                type: 'typing',
                payload: { 
                  userId, 
                  recipientId: status.recipientId, 
                  isDirectMessage: true,
                  isTyping: false 
                }
              }));
              break;
            }
          }
        } else if (status.channelId) {
          // For channel messages, broadcast to the channel
          broadcastToChannel(status.channelId, {
            type: 'typing',
            payload: { 
              userId, 
              channelId: status.channelId, 
              isDirectMessage: false,
              isTyping: false 
            }
          });
        }
      }
    });
  }, 5000);

  return httpServer;
}
